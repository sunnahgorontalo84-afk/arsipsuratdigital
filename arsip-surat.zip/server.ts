import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Body parser limit increase for attachments
  app.use(express.json({ limit: '10mb' }));

  // Initialize Gemini lazily
  let ai: GoogleGenAI | null = null;
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }

  // API routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", aiEnabled: !!apiKey });
  });

  app.post("/api/generate-letter", async (req, res) => {
    const { title, category, sender, recipient, context } = req.body;

    if (!apiKey) {
      return res.status(500).json({ 
        error: "Kunci API Gemini (GEMINI_API_KEY) belum dikonfigurasi di server. Silakan konfigurasi di Settings > Secrets." 
      });
    }

    if (!ai) {
      ai = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }

    try {
      const prompt = `Buatkan surat resmi profesional dalam Bahasa Indonesia yang lengkap dan berstruktur rapi.

Kriteria/Informasi Surat:
- Judul/Perihal: ${title}
- Kategori/Sifat: ${category}
- Pengirim: ${sender}
- Penerima: ${recipient}
- Detail Konteks/Tujuan Tambahan: ${context || 'Tidak ada catatan tambahan.'}

Aturan Penulisan Surat:
1. Mulai langsung dari Salam Pembuka (contoh: "Dengan hormat,").
2. Tulis isi surat resmi yang terdiri dari:
   - Paragraf Pembuka yang merujuk pada maksud surat.
   - Paragraf Isi yang mendetailkan maksud secara runut, padat, dan informatif.
   - Paragraf Penutup (contoh: "Demikian kami sampaikan, atas kerja sama Bapak/Ibu...").
   - Salam Penutup (contoh: "Hormat kami," atau "Wassalamu'alaikum Wr. Wb.").
3. PERINGATAN PENTING: Jangan menyertakan kop surat, nomor surat, tanggal surat, atau nama penandatangan di kolom tanda tangan di bagian akhir surat, karena elemen-elemen tersebut akan dipasang secara dinamis dan otomatis oleh aplikasi sistem kearsipan.
4. Gunakan gaya bahasa formal dan santun, sesuai tata bahasa baku Bahasa Indonesia (PUEBI).`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.7,
        }
      });

      const text = response.text || "";
      res.json({ text });
    } catch (err: any) {
      console.error("Gemini API Error:", err);
      res.status(500).json({ error: "Gagal membuat isi surat dengan AI: " + (err.message || err) });
    }
  });

  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
