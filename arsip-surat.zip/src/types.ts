/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type LetterType = 'masuk' | 'keluar';

export type LetterPriority = 'biasa' | 'penting' | 'sangat_penting' | 'rahasia';

export type LetterStatus = 'diarsipkan' | 'butuh_follow_up' | 'dalam_proses' | 'selesai';

export interface Letter {
  id: string;
  number: string; // Nomor Surat (e.g., 102/UND/VI/2026)
  title: string; // Perihal / Subjek
  date: string; // Tanggal Surat
  receivedOrSentDate: string; // Tanggal Diterima / Tanggal Dikirim
  senderOrRecipient: string; // Asal Surat (Masuk) atau Tujuan Surat (Keluar)
  category: string; // Kategori / Klasifikasi (Undangan, Keuangan, Dinas, dll)
  type: LetterType; // Jenis Surat (Masuk / Keluar)
  priority: LetterPriority; // Sifat Surat / Prioritas
  status: LetterStatus; // Status Penanganan
  disposition: string; // Disposisi / Instruksi Lanjutan
  summary: string; // Ringkasan / Isi Singkat
  attachmentName?: string; // Nama File Lampiran
  attachmentSize?: number; // Ukuran File Lampiran
  attachmentType?: string; // Tipe File Lampiran
  attachmentData?: string; // Base64 data atau custom raw text untuk previewer cetak
  signerName?: string; // Nama Penandatangan (untuk kop surat simulasi)
  signerRole?: string; // Jabatan Penandatangan (untuk kop surat simulasi)
  institutionName?: string; // Nama Instansi Pengirim (untuk kop surat simulasi)
  kopLogoUrl?: string; // Base64 data URL logo kustom
  kopFontFamily?: string; // Nama font family pilihan untuk kop
}

export interface ArchiveStats {
  totalLetters: number;
  totalIncoming: number;
  totalOutgoing: number;
  byCategory: Record<string, number>;
  byStatus: Record<LetterStatus, number>;
  byPriority: Record<LetterPriority, number>;
}

export const LETTER_CATEGORIES = [
  'Surat ke Kemenag',
  'Siswa / Kesiswaan',
  'Legalisir',
  'Dinas / Pemerintahan',
  'Undangan / Kegiatan',
  'Keputusan / SK',
  'Keuangan / Invoice',
  'Kerjasama / MoU',
  'Pemberitahuan / Edaran',
  'Ketenagakerjaan / SDM',
  'Penawaran Barang/Jasa',
  'Lain-lain'
];

export const PRIORITY_CONFIG = {
  biasa: { label: 'Biasa', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  penting: { label: 'Penting', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  sangat_penting: { label: 'Sangat Penting', color: 'bg-orange-50 text-orange-700 border-orange-200' },
  rahasia: { label: 'Rahasia / Privat', color: 'bg-rose-50 text-rose-700 border-rose-200' },
};

export const STATUS_CONFIG = {
  diarsipkan: { label: 'Diarsipkan', color: 'bg-slate-100 text-slate-800 ring-slate-600/20' },
  butuh_follow_up: { label: 'Butuh Tindak Lanjut', color: 'bg-red-50 text-red-700 ring-red-600/10' },
  dalam_proses: { label: 'Dalam Proses', color: 'bg-sky-50 text-sky-700 ring-sky-700/10' },
  selesai: { label: 'Selesai', color: 'bg-green-50 text-green-700 ring-green-600/15' },
};
