/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  FolderLock, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Download, 
  Upload, 
  CheckCircle,
  HelpCircle,
  Clock,
  ExternalLink,
  BookMarked,
  Sparkles,
  LogOut
} from 'lucide-react';
import { Letter, LetterType, LetterPriority, LetterStatus } from './types';
import { INITIAL_LETTERS } from './initialData';
import { StatsGrid } from './components/StatsGrid';
import { LetterFilter } from './components/LetterFilter';
import { LetterTable } from './components/LetterTable';
import { LetterForm } from './components/LetterForm';
import { LetterPreview } from './components/LetterPreview';
import { LetterCreator } from './components/LetterCreator';
import { AdminLogin } from './components/AdminLogin';

export default function App() {
  const [letters, setLetters] = useState<Letter[]>([]);
  const [selectedLetterId, setSelectedLetterId] = useState<string | undefined>(undefined);
  const [showForm, setShowForm] = useState(false);
  const [showCreator, setShowCreator] = useState(false);

  // App Admin Authentication State
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(() => {
    return localStorage.getItem('sh_arsip_admin_session') === 'true';
  });

  const handleLoginSuccess = (username: string) => {
    setIsAdminLoggedIn(true);
    localStorage.setItem('sh_arsip_admin_session', 'true');
    showToast(`Selamat datang kembali, Admin Tata Usaha Madrasah!`, 'success');
  };

  const handleLogout = () => {
    if (window.confirm('Apakah Anda yakin ingin keluar dari sistem kearsipan?')) {
      setIsAdminLoggedIn(false);
      localStorage.removeItem('sh_arsip_admin_session');
      setSelectedLetterId(undefined);
      setShowForm(false);
      setShowCreator(false);
      showToast('Sesi Anda telah diakhiri dengan aman.', 'info');
    }
  };

  // Filter States
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'semua' | 'masuk' | 'keluar'>('semua');
  const [selectedCategory, setSelectedCategory] = useState('Semua Kategori');
  const [selectedPriority, setSelectedPriority] = useState('Semua');
  const [selectedStatus, setSelectedStatus] = useState('Semua');

  // Interactive feedback state
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'info' | 'error'>('success');

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Initialize from LocalStorage
  useEffect(() => {
    const saved = localStorage.getItem('sh_arsip_surat_db');
    if (saved) {
      try {
        setLetters(JSON.parse(saved));
      } catch (e) {
        setLetters(INITIAL_LETTERS);
        localStorage.setItem('sh_arsip_surat_db', JSON.stringify(INITIAL_LETTERS));
      }
    } else {
      setLetters(INITIAL_LETTERS);
      localStorage.setItem('sh_arsip_surat_db', JSON.stringify(INITIAL_LETTERS));
    }
  }, []);

  // Save to LocalStorage helper
  const saveLetters = (newLetters: Letter[]) => {
    setLetters(newLetters);
    localStorage.setItem('sh_arsip_surat_db', JSON.stringify(newLetters));
  };

  // Reset database back to default preset letters
  const handleResetDatabase = () => {
    if (window.confirm('Apakah Anda yakin ingin mengatur ulang data kearsipan ke data bawaan simulasi? Ini akan menghapus data yang Anda buat.')) {
      saveLetters(INITIAL_LETTERS);
      setSelectedLetterId(undefined);
      setShowForm(false);
      showToast('Database berhasil diatur ulang ke data bawaan.', 'info');
    }
  };

  // Create a new letter
  const handleAddLetter = (newLetterFields: Omit<Letter, 'id'>) => {
    const newId = `l-${Date.now()}`;
    const created: Letter = {
      ...newLetterFields,
      id: newId,
    };
    const updatedList = [created, ...letters];
    saveLetters(updatedList);
    setShowForm(false);
    setShowCreator(false);
    setSelectedLetterId(newId); // auto focus preview
    showToast(`Dokumen nomor "${newLetterFields.number}" berhasil diarsipkan!`, 'success');
  };

  // Update Existing Letter (e.g., Change status or disposition from preview)
  const handleUpdateLetter = (updated: Letter) => {
    const updatedList = letters.map((l) => (l.id === updated.id ? updated : l));
    saveLetters(updatedList);
    showToast(`Disposisi & status dokumen "${updated.number}" berhasil diperbarui.`, 'success');
  };

  // Delete a letter from archive
  const handleDeleteLetter = (id: string) => {
    const letterToDelete = letters.find((l) => l.id === id);
    if (!letterToDelete) return;

    if (window.confirm(`Hapus arsip surat "${letterToDelete.title}" dengan nomor [${letterToDelete.number}]?`)) {
      const filtered = letters.filter((l) => l.id !== id);
      saveLetters(filtered);
      if (selectedLetterId === id) {
        setSelectedLetterId(undefined);
      }
      showToast(`Arsip surat "${letterToDelete.title}" telah dihapus secara permanen.`, 'error');
    }
  };

  // Clear all filter dropdowns
  const handleClearFilters = () => {
    setSearchTerm('');
    setSelectedType('semua');
    setSelectedCategory('Semua Kategori');
    setSelectedPriority('Semua');
    setSelectedStatus('Semua');
    showToast('Semua kuari pencarian dibersihkan.', 'info');
  };

  // Export database to a standard JSON file
  const handleExportJSON = () => {
    const dataStr = JSON.stringify(letters, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);

    const exportFileDefaultName = `Arsip_Surat_Backup_${new Date().toISOString().split('T')[0]}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    showToast('Berkas cadangan arsip berhasil diunduh.', 'success');
  };

  // Import database from JSON
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    const file = e.target.files?.[0];
    if (!file) return;

    fileReader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].number) {
          saveLetters(parsed);
          setSelectedLetterId(undefined);
          showToast(`Berhasil mengimpor ${parsed.length} arsip surat dari file cadangan.`, 'success');
        } else {
          showToast('Format berkas tidak sesuai. Harus berupa JSON daftar arsip surat valid.', 'error');
        }
      } catch (error) {
        showToast('Gagal mengurai file JSON. Pastikan berkas tidak rusak.', 'error');
      }
    };
    fileReader.readAsText(file);
    e.target.value = ''; // Reset input
  };

  // Filtering Calculation
  const filteredLetters = useMemo(() => {
    return letters.filter((l) => {
      // Search term query
      const matchSearch =
        searchTerm === '' ||
        l.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        l.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        l.senderOrRecipient.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (l.summary && l.summary.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (l.disposition && l.disposition.toLowerCase().includes(searchTerm.toLowerCase()));

      // Type
      const matchType = selectedType === 'semua' || l.type === selectedType;

      // Category
      const matchCategory = selectedCategory === 'Semua Kategori' || l.category === selectedCategory;

      // Priority
      const matchPriority = selectedPriority === 'Semua' || l.priority === selectedPriority;

      // Status
      const matchStatus = selectedStatus === 'Semua' || l.status === selectedStatus;

      return matchSearch && matchType && matchCategory && matchPriority && matchStatus;
    });
  }, [letters, searchTerm, selectedType, selectedCategory, selectedPriority, selectedStatus]);

  // Selected letter full object lookup
  const selectedLetter = useMemo(() => {
    return letters.find((l) => l.id === selectedLetterId);
  }, [letters, selectedLetterId]);

  if (!isAdminLoggedIn) {
    return (
      <>
        <AdminLogin onLoginSuccess={handleLoginSuccess} />
        {toastMessage && (
          <div className="fixed top-4 right-4 z-50 animate-bounce">
            <div className={`p-3 px-4 rounded-xl shadow-lg border text-xs font-bold flex items-center gap-2 ${
              toastType === 'success' 
                ? 'bg-zinc-950/90 border-emerald-500/40 text-emerald-300 shadow-emerald-500/10' 
                : toastType === 'error'
                ? 'bg-zinc-950/90 border-red-500/40 text-red-300 shadow-red-500/10'
                : 'bg-zinc-950/90 border-sky-500/40 text-sky-300 shadow-sky-500/10'
            }`}>
              <CheckCircle className={`h-4.5 w-4.5 ${
                toastType === 'success' ? 'text-emerald-400' : toastType === 'error' ? 'text-red-400' : 'text-sky-400'
              }`} />
              <span>{toastMessage}</span>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-100 leading-normal relative overflow-x-hidden bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.12),rgba(255,255,255,0))]">
      {/* Top Banner / Application Header */}
      <header className="bg-black/80 backdrop-blur-md border-b border-emerald-500/20 sticky top-0 z-40 shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
        <div className="w-full px-2 sm:px-4 lg:px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-xl shadow-lg shadow-emerald-500/20 ring-4 ring-emerald-500/10">
              <FolderLock className="h-6 w-6 stroke-2" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-extrabold font-sans tracking-tight bg-clip-text bg-gradient-to-r from-slate-50 via-emerald-100 to-slate-200">
                  Arsip Surat Digital
                </span>
                <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30 font-mono scale-95">
                  v1.5 Emerald Glass
                </span>
              </div>
              <p className="text-xs text-emerald-400/80 font-semibold mt-0.5">
                Portal Pencatatan, Disposisi, dan Validasi Administrasi Surat Masuk & Surat Keluar
              </p>
            </div>
          </div>

          {/* Quick global action buttons area with stacked Logout button */}
          <div className="flex flex-col items-end gap-2 shrink-0">
            <div className="flex flex-wrap items-center gap-2.5">
              {/* Import / Export / Reset tools */}
              <div className="flex items-center gap-1.5 p-1 bg-zinc-900 border border-emerald-500/20 rounded-lg text-xs">
                {/* Reset seed button */}
                <button
                  onClick={handleResetDatabase}
                  className="p-1.5 font-bold text-slate-400 hover:text-red-400 hover:bg-zinc-850 rounded-md transition-all flex items-center gap-1 cursor-pointer"
                  title="Atur ulang database surat ke bawaan"
                >
                  <RotateCcw className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">Reset</span>
                </button>

                {/* Export backup button */}
                <button
                  onClick={handleExportJSON}
                  className="p-1.5 font-bold text-slate-400 hover:text-emerald-300 hover:bg-zinc-850 rounded-md transition-all flex items-center gap-1 cursor-pointer"
                  title="Cadangkan data arsip ke berkas JSON"
                >
                  <Download className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">Ekspor</span>
                </button>

                {/* Import backup simulation file-trigger */}
                <label 
                  className="p-1.5 font-bold text-slate-400 hover:text-emerald-300 hover:bg-zinc-850 rounded-md transition-all flex items-center gap-1 cursor-pointer"
                  title="Unggah berkas cadangan JSON"
                >
                  <Upload className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="hidden sm:inline">Impor</span>
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={handleImportJSON}
                  />
                </label>
              </div>

              {/* Creator Toggle Button */}
              <button
                onClick={() => {
                  setShowCreator(!showCreator);
                  setShowForm(false);
                  setSelectedLetterId(undefined);
                }}
                className={`px-4 py-2 border font-bold rounded-lg text-xs tracking-wide flex items-center gap-1.5 transition-all shadow-md shrink-0 cursor-pointer ${
                  showCreator 
                    ? 'bg-zinc-900 text-white border-emerald-500 hover:bg-zinc-800' 
                    : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border-emerald-500/25'
                }`}
              >
                <Sparkles className="h-4.5 w-4.5 text-emerald-400" />
                {showCreator ? 'Lihat Arsip' : 'Buat Format Mandiri (AI)'}
              </button>

              {/* Main Add letter button */}
              <button
                onClick={() => {
                  setShowForm(!showForm);
                  setShowCreator(false);
                  setSelectedLetterId(undefined); // dismiss preview when creating new letter
                }}
                className={`px-4 py-2 border font-bold rounded-lg text-xs tracking-wide flex items-center gap-1.5 transition-all shadow-md shrink-0 cursor-pointer ${
                  showForm 
                    ? 'bg-zinc-900 text-white border-emerald-500 hover:bg-zinc-800' 
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500/30 hover:shadow-emerald-500/20'
                }`}
              >
                <Plus className="h-4.5 w-4.5" />
                {showForm ? 'Lihat Arsip' : 'Arsip Surat Baru'}
              </button>
            </div>

            {/* Logout button placed in "pojok kanan bawah" of the header, below the main action buttons */}
            <button
              onClick={handleLogout}
              className="py-1 px-3 bg-red-500/15 hover:bg-red-500/30 text-red-300 border border-red-500/25 hover:border-red-500/55 rounded-md text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="Keluar dari sesi admin"
            >
              <LogOut className="h-3 w-3" />
              <span>Keluar Sesi</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="w-full px-2 sm:px-4 lg:px-6 py-6 space-y-6 flex-1 flex flex-col justify-start">
        
        {/* Dynamic State Toast Notifications */}
        {toastMessage && (
          <div className="fixed top-4 right-4 z-50 animate-bounce">
            <div className={`p-3 px-4 rounded-xl shadow-lg border text-xs font-bold flex items-center gap-2 ${
              toastType === 'success' 
                ? 'bg-zinc-950/90 border-emerald-500/40 text-emerald-300 shadow-emerald-500/10' 
                : toastType === 'error'
                ? 'bg-zinc-950/90 border-red-500/40 text-red-300 shadow-red-500/10'
                : 'bg-zinc-950/90 border-sky-500/40 text-sky-300 shadow-sky-500/10'
            }`}>
              <CheckCircle className={`h-4.5 w-4.5 ${
                toastType === 'success' ? 'text-emerald-400' : toastType === 'error' ? 'text-red-400' : 'text-sky-400'
              }`} />
              <span>{toastMessage}</span>
            </div>
          </div>
        )}

        {/* Stats Grid Dashboard row */}
        <StatsGrid letters={letters} />

        {/* Dynamic Display Layout */}
        {showCreator ? (
          <div className="animate-fade-in">
            <LetterCreator 
              onAddLetter={handleAddLetter} 
              onClose={() => setShowCreator(false)} 
            />
          </div>
        ) : showForm ? (
          /* Form Pane takes priority over general screen to provide serene writing stage */
          <div className="animate-fade-in">
            <LetterForm 
              onAddLetter={handleAddLetter} 
              onClose={() => setShowForm(false)} 
            />
          </div>
        ) : (
          /* Default workspace: Filters, Lists and Splitted preview panels */
          <div className="space-y-4 flex-1 flex flex-col justify-start">
            
            {/* Filter Control Section */}
            <LetterFilter
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              selectedType={selectedType}
              setSelectedType={setSelectedType}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              selectedPriority={selectedPriority}
              setSelectedPriority={setSelectedPriority}
              selectedStatus={selectedStatus}
              setSelectedStatus={setSelectedStatus}
              onClearFilters={handleClearFilters}
            />

            {/* Split layout workspace */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch flex-1">
              
              {/* Left Side: Letter Catalog list */}
              <div className={`${selectedLetter ? 'lg:col-span-7' : 'lg:col-span-12'} transition-all duration-300 flex flex-col`}>
                <LetterTable
                  letters={filteredLetters}
                  onSelectLetter={(l) => {
                    setSelectedLetterId(l.id);
                  }}
                  onDeleteLetter={handleDeleteLetter}
                  selectedLetterId={selectedLetterId}
                />
              </div>

              {/* Right Side: Expandable Letter Preview Panel (Only displays on active row click) */}
              {selectedLetter && (
                <div className="lg:col-span-5 h-[842px] sticky top-6 animate-slide-in">
                  <LetterPreview
                    letter={selectedLetter}
                    onClose={() => setSelectedLetterId(undefined)}
                    onUpdateLetter={handleUpdateLetter}
                  />
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Software Footer */}
      <footer className="bg-black/90 border-t border-emerald-500/15 py-6 text-center text-xs text-slate-500 font-medium font-sans">
        <div className="w-full px-2 sm:px-4 lg:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 mx-auto">
          <p>&copy; 2026 Arsip Madrasah Digital | Sekretariat Tata Usaha Madrasah.</p>
          <div className="flex items-center gap-4 text-[10px] uppercase tracking-wider text-emerald-500/60 font-bold">
            <span>Enkripsi Database: AES-LOKAL</span>
            <span>&bull;</span>
            <span>Sifat Berkas: Legal-Formal</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
