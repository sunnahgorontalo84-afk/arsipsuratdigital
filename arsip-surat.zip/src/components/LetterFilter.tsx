/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Search, Filter, RefreshCw, X } from 'lucide-react';
import { LETTER_CATEGORIES, LetterStatus, LetterPriority } from '../types';

interface LetterFilterProps {
  searchTerm: string;
  setSearchTerm: (s: string) => void;
  selectedType: 'semua' | 'masuk' | 'keluar';
  setSelectedType: (t: 'semua' | 'masuk' | 'keluar') => void;
  selectedCategory: string;
  setSelectedCategory: (c: string) => void;
  selectedPriority: string;
  setSelectedPriority: (p: string) => void;
  selectedStatus: string;
  setSelectedStatus: (s: string) => void;
  onClearFilters: () => void;
}

export const LetterFilter: React.FC<LetterFilterProps> = ({
  searchTerm,
  setSearchTerm,
  selectedType,
  setSelectedType,
  selectedCategory,
  setSelectedCategory,
  selectedPriority,
  setSelectedPriority,
  selectedStatus,
  setSelectedStatus,
  onClearFilters,
}) => {
  const isFiltered =
    searchTerm !== '' ||
    selectedType !== 'semua' ||
    selectedCategory !== 'Semua Kategori' ||
    selectedPriority !== 'Semua' ||
    selectedStatus !== 'Semua';

  return (
    <div className="bg-zinc-950/65 backdrop-blur-md rounded-xl border border-emerald-500/20 shadow-xl p-4 flex flex-col gap-4">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
        {/* Search Input */}
        <div className="relative lg:col-span-4">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4.5 w-4.5 text-emerald-400/80" />
          </div>
          <input
            type="text"
            className="block w-full pl-9 pr-3 py-2 border border-emerald-500/25 rounded-lg text-sm bg-zinc-900/50 hover:bg-zinc-900/80 focus:bg-zinc-950 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-400 text-slate-100 placeholder-slate-500 transition-colors"
            placeholder="Cari perihal, nomor surat, instansi..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Jenis Surat buttons */}
        <div className="flex bg-zinc-900/80 p-1 rounded-lg lg:col-span-3 border border-emerald-500/15">
          <button
            type="button"
            className={`flex-1 text-center py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
              selectedType === 'semua'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/15'
                : 'text-slate-400 hover:text-emerald-400'
            }`}
            onClick={() => setSelectedType('semua')}
          >
            Semua
          </button>
          <button
            type="button"
            className={`flex-1 text-center py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
              selectedType === 'masuk'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/15'
                : 'text-slate-400 hover:text-emerald-400'
            }`}
            onClick={() => setSelectedType('masuk')}
          >
            Masuk
          </button>
          <button
            type="button"
            className={`flex-1 text-center py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
              selectedType === 'keluar'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/15'
                : 'text-slate-400 hover:text-emerald-400'
            }`}
            onClick={() => setSelectedType('keluar')}
          >
            Keluar
          </button>
        </div>

        {/* Sub-Filters selectors */}
        <div className="grid grid-cols-3 gap-2 lg:col-span-5">
          {/* Category */}
          <div>
            <select
              className="block w-full px-2 py-2 border border-emerald-500/25 rounded-lg text-xs bg-zinc-900/50 hover:bg-zinc-900 text-slate-200 font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-400 transition-colors"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="Semua Kategori" className="bg-zinc-950 text-slate-100">Kategori (Semua)</option>
              {LETTER_CATEGORIES.map((c) => (
                <option key={c} value={c} className="bg-zinc-950 text-slate-200">
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Priority */}
          <div>
            <select
              className="block w-full px-2 py-2 border border-emerald-500/25 rounded-lg text-xs bg-zinc-900/50 hover:bg-zinc-900 text-slate-200 font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-400 transition-colors"
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
            >
              <option value="Semua" className="bg-zinc-950 text-slate-100">Prioritas (Semua)</option>
              <option value="biasa" className="bg-zinc-950 text-slate-200">Biasa</option>
              <option value="penting" className="bg-zinc-950 text-slate-200">Penting</option>
              <option value="sangat_penting" className="bg-zinc-950 text-slate-200">Sangat Penting</option>
              <option value="rahasia" className="bg-zinc-950 text-slate-200">Rahasia</option>
            </select>
          </div>

          {/* Status */}
          <div>
            <select
              className="block w-full px-2 py-2 border border-emerald-500/25 rounded-lg text-xs bg-zinc-900/50 hover:bg-zinc-900 text-slate-200 font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-400 transition-colors"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
            >
              <option value="Semua" className="bg-zinc-950 text-slate-100">Status (Semua)</option>
              <option value="diarsipkan" className="bg-zinc-950 text-slate-200">Diarsipkan</option>
              <option value="butuh_follow_up" className="bg-zinc-950 text-slate-200">Tindak Lanjut</option>
              <option value="dalam_proses" className="bg-zinc-950 text-slate-200">Dalam Proses</option>
              <option value="selesai" className="bg-zinc-950 text-slate-200">Selesai</option>
            </select>
          </div>
        </div>
      </div>

      {isFiltered && (
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2.5 border-t border-emerald-500/15">
          <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-400">
            <span className="font-bold text-emerald-400/80 flex items-center gap-1">
              <Filter className="h-3 w-3" /> Filter Aktif:
            </span>
            {selectedType !== 'semua' && (
              <span className="px-2 py-0.5 rounded-full font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[10px]">
                Surat {selectedType === 'masuk' ? 'Masuk' : 'Keluar'}
              </span>
            )}
            {selectedCategory !== 'Semua Kategori' && (
              <span className="px-2 py-0.5 bg-zinc-900 border border-emerald-500/20 text-slate-300 rounded-full font-semibold text-[10px]">
                {selectedCategory}
              </span>
            )}
            {selectedPriority !== 'Semua' && (
              <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/25 text-amber-300 rounded-full font-semibold text-[10px] capitalize">
                Sifat: {selectedPriority.replace('_', ' ')}
              </span>
            )}
            {selectedStatus !== 'Semua' && (
              <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/25 text-emerald-300 rounded-full font-semibold text-[10px] capitalize">
                Status: {selectedStatus.replace('_', ' ')}
              </span>
            )}
            {searchTerm !== '' && (
              <span className="px-2 py-0.5 bg-sky-500/10 border border-sky-500/25 text-sky-300 rounded-full font-semibold text-[10px] truncate max-w-xs">
                Kata kunci: &ldquo;{searchTerm}&rdquo;
              </span>
            )}
          </div>
          <button
            type="button"
            className="text-[11px] text-red-400 hover:text-red-300 font-bold flex items-center gap-1 py-1 px-2.5 rounded-md hover:bg-red-500/10 border border-transparent hover:border-red-500/25 transition-all cursor-pointer"
            onClick={onClearFilters}
          >
            <RefreshCw className="h-3 w-3" /> Bersihkan Filter
          </button>
        </div>
      )}
    </div>
  );
};
