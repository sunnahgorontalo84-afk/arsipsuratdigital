/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Download, 
  ExternalLink, 
  Tag, 
  FileText, 
  Calendar, 
  Bookmark, 
  MessageSquareCode, 
  QrCode,
  Building2,
  CheckCircle,
  FileCheck2,
  Lock
} from 'lucide-react';
import { Letter, LetterPriority, LetterStatus, PRIORITY_CONFIG, STATUS_CONFIG } from '../types';

interface LetterPreviewProps {
  letter: Letter;
  onClose: () => void;
  onUpdateLetter: (updated: Letter) => void;
}

export const LetterPreview: React.FC<LetterPreviewProps> = ({
  letter,
  onClose,
  onUpdateLetter,
}) => {
  const [status, setStatus] = useState<LetterStatus>(letter.status);
  const [disposition, setDisposition] = useState(letter.disposition || '');
  const [isSaved, setIsSaved] = useState(false);

  // Sync state with prop if letter changes
  useEffect(() => {
    setStatus(letter.status);
    setDisposition(letter.disposition || '');
    setIsSaved(false);
  }, [letter]);

  const priorityConf = PRIORITY_CONFIG[letter.priority] || PRIORITY_CONFIG.biasa;
  const statusConf = STATUS_CONFIG[status] || STATUS_CONFIG.diarsipkan;

  const handleSaveStatusAndDisposition = () => {
    onUpdateLetter({
      ...letter,
      status,
      disposition: disposition.trim(),
    });
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, 2000);
  };

  const handlePrint = () => {
    // Focus and print only the letter sheet
    const printContent = document.getElementById('letter-sheet-print-area');
    if (!printContent) return;

    const originalContent = document.body.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    
    if (printWindow) {
      printWindow.document.write('<html><head><title>Cetak Surat Arsip</title>');
      // Inject Tailwind CDN to keep styling intact during printing
      printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
      printWindow.document.write('<link href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono&display=swap" rel="stylesheet">');
      printWindow.document.write('<style>@media print { body { -webkit-print-color-adjust: exact; } } body { font-family: "Inter", sans-serif; }</style>');
      printWindow.document.write('</head><body class="p-8 bg-white">');
      printWindow.document.write(printContent.innerHTML);
      printWindow.document.write('</body></html>');
      
      printWindow.document.close();
      // Wait for fonts/styles to load safely
      setTimeout(() => {
        printWindow.focus();
        printWindow.print();
        printWindow.close();
      }, 750);
    }
  };

  return (
    <div className="bg-zinc-950/60 backdrop-blur-md rounded-xl border border-emerald-500/20 shadow-xl overflow-hidden h-full flex flex-col">
      {/* Detail header */}
      <div className="bg-zinc-900 px-5 py-4 border-b border-emerald-500/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="p-1 px-2.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-lg text-xs font-bold font-mono">
            ID: {letter.id}
          </span>
          <h2 className="text-base font-bold text-slate-100 line-clamp-1">Lembar Disposisi & Preview</h2>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={handlePrint}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-zinc-800 rounded-md transition-colors cursor-pointer"
            title="Cetak Surat Resmi"
          >
            <Printer className="h-4.5 w-4.5 text-emerald-400" />
          </button>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-zinc-800 rounded-md transition-colors cursor-pointer"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto grid grid-cols-1 xl:grid-cols-12 divide-y xl:divide-y-0 xl:divide-x divide-slate-100">
        {/* Left column: Realistic simulated letterhead print render */}
        <div className="xl:col-span-8 p-6 bg-slate-100 flex justify-center overflow-y-auto min-h-[500px]">
          <div 
            id="letter-sheet-print-area" 
            className="w-full max-w-2xl bg-white shadow-md border border-slate-200/60 p-8 flex flex-col justify-between"
            style={{ minHeight: '842px', aspectRatio: '1 / 1.414' }} // A4 proportions
          >
            <div>
              {/* Kop Surat Header */}
              <div 
                className="text-center pb-4 border-b-4 border-double border-slate-800 flex items-center justify-center gap-3"
                style={letter.kopFontFamily ? { fontFamily: letter.kopFontFamily } : undefined}
              >
                {letter.kopLogoUrl && letter.kopLogoUrl !== 'none' && (
                  <div className="shrink-0">
                    {letter.kopLogoUrl.startsWith('data:image') ? (
                      <img 
                        src={letter.kopLogoUrl} 
                        alt="Logo" 
                        className="h-12 w-12 object-contain rounded-md" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="h-10 w-10 flex items-center justify-center bg-emerald-500 text-white rounded-full font-bold shadow-xs text-base">
                        {letter.kopLogoUrl === 'garuda' ? '🦅' : letter.kopLogoUrl === 'bintang' ? '⭐' : letter.kopLogoUrl === 'daun' ? '🍃' : '🌐'}
                      </div>
                    )}
                  </div>
                )}
                
                <div className="text-center col-span-12 w-full">
                  <div className="text-xs sm:text-sm font-extrabold uppercase tracking-wide text-slate-900 leading-tight">
                    {letter.institutionName || 'KEMENTERIAN SEKRETARIAT KEBANGSAAN'}
                  </div>
                  <div className="text-[9px] font-bold text-slate-700 uppercase tracking-wider mt-0.5">
                    {letter.signerRole?.toLowerCase().includes('dinas') ? 'PEMERINTAH DAERAH KABUPATEN / KOTA' : 'REPUBLIK INDONESIA'}
                  </div>
                  <div className="text-[8px] sm:text-[9px] text-slate-500 font-medium font-sans mt-0.5">
                    {letter.signerRole?.toLowerCase().includes('dinas') 
                      ? 'Jl. Jend. Sudirman No. 12, Gorontalo, 96115 | Telp: (0435) 821156 | Email: diskominfo@gorontalokota.go.id' 
                      : 'Jalan Jenderal Sudirman No. 42 / 45, Kompleks Area Sektoral B | Telp: (021) 500-1200 | Email: tu-sekretaris@arsip.go.id'}
                  </div>
                </div>
              </div>

              {/* Letter Title / Type */}
              <div className="mt-6 text-center">
                <div className="text-xs font-bold uppercase text-slate-800 tracking-wide underline">
                  {letter.category.replace(/[^a-zA-Z0-9\s/]/g, '') || 'SURAT ADMINISTRASI'}
                </div>
                <div className="text-[10px] font-mono text-slate-500 mt-1">
                  Nomor: {letter.number}
                </div>
              </div>

              {/* Formal info block */}
              <div className="mt-8 text-xs grid grid-cols-12 gap-y-1.5 font-medium text-slate-700">
                <div className="col-span-2 text-slate-400">Sifat</div>
                <div className="col-span-10">: &nbsp;<span className="uppercase font-semibold tracking-wide">{letter.priority}</span></div>

                <div className="col-span-2 text-slate-400">Lampiran</div>
                <div className="col-span-10">: &nbsp;{letter.attachmentName ? `1 (Satu) Berkas Digital (${letter.attachmentName})` : 'Nihil'}</div>

                <div className="col-span-2 text-slate-400">Perihal</div>
                <div className="col-span-10 flex">
                  <span className="font-bold">: &nbsp;</span>
                  <span className="font-bold text-slate-800 uppercase underline text-[11px] leading-tight block flex-1">
                    {letter.title}
                  </span>
                </div>
              </div>

              {/* Sender Recipient indicator block */}
              <div className="mt-6 text-xs text-slate-700 border-t border-b border-slate-100 py-3">
                {letter.type === 'masuk' ? (
                  <div>
                    <span className="text-slate-400">Surat Masuk dari: </span>
                    <span className="font-bold text-slate-800 block mt-1">{letter.senderOrRecipient}</span>
                  </div>
                ) : (
                  <div>
                    <span className="text-slate-400">Surat Keluar dikirim ke: </span>
                    <span className="font-bold text-slate-800 block mt-1">{letter.senderOrRecipient}</span>
                  </div>
                )}
              </div>

              {/* Body Content */}
              <div className="mt-6 text-xs text-slate-800 font-sans leading-relaxed whitespace-pre-wrap font-medium">
                {letter.summary}
              </div>
            </div>

            {/* Bottom Signature and Stamp Area */}
            <div className="mt-12 pt-6 border-t border-slate-100 grid grid-cols-12 gap-4 items-end text-xs">
              <div className="col-span-7">
                {/* Bagian Terautentikasi ditiadakan atas keputusan pengguna */}
              </div>

              <div className="col-span-5 text-right flex flex-col items-end">
                <div className="text-[10px] text-slate-400 leading-none">Gorontalo, {letter.date}</div>
                <div className="text-[10px] font-bold text-slate-850 mt-1 uppercase max-w-[200px] leading-tight">
                  {letter.signerRole || 'Plt. Kepala Tata Usaha'}
                </div>
                {/* Large official spacer for sign */}
                <div className="h-14 flex items-center justify-center relative">
                  {letter.attachmentData && letter.attachmentData.startsWith('data:image') ? (
                    <img 
                      src={letter.attachmentData} 
                      alt="Tanda Tangan Digital" 
                      className="absolute h-14 object-contain max-w-[150px] mix-blend-darken filter contrast-125" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="border border-green-500/20 bg-green-50/50 text-[10px] px-2.5 py-0.5 rounded-sm flex items-center gap-1 text-green-700 font-semibold tracking-wider uppercase scale-90">
                      <FileCheck2 className="h-3 w-3" /> Signed & Verified
                    </div>
                  )}
                </div>
                <div className="text-xs font-bold text-slate-850 border-b border-slate-700 pb-0.5 uppercase">
                  {letter.signerName || 'AHMAD RIDWAN, S.H.'}
                </div>
                <div className="text-[8px] font-mono text-slate-500 mt-1">NIP. 19780410 200501 1 002</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Form to update state, disposition, & view file details */}
        <div className="xl:col-span-4 p-5 space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            {/* Meta Tags Quick-View */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Informasi Arsip</h3>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/60 divide-y divide-slate-100 text-xs gap-3">
                <div className="flex items-center justify-between pb-2">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <Bookmark className="h-3.5 w-3.5 text-slate-400" /> Sifat Surat
                  </span>
                  <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-sm border ${priorityConf.color}`}>
                    {priorityConf.label}
                  </span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" /> Tanggal Surat
                  </span>
                  <span className="font-medium text-slate-700 font-mono">{letter.date}</span>
                </div>
                <div className="flex items-center justify-between py-2">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-slate-400" /> Registrasi {letter.type === 'masuk' ? 'Diterima' : 'Dikirim'}
                  </span>
                  <span className="font-medium text-slate-700 font-mono">{letter.receivedOrSentDate}</span>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <span className="text-slate-500 font-medium flex items-center gap-1.5">
                    <Tag className="h-3.5 w-3.5 text-slate-400" /> Kategori Klasifikasi
                  </span>
                  <span className="font-semibold text-indigo-700 max-w-[140px] truncate" title={letter.category}>
                    {letter.category}
                  </span>
                </div>
              </div>
            </div>

            {/* Document Digital Attachment Status */}
            <div>
              <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Berkas Lampiran Resmi</h3>
              {letter.attachmentName ? (
                <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="bg-emerald-100 p-1.5 rounded-lg text-emerald-800">
                      <FileCheck2 className="h-4 w-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-slate-700 truncate max-w-[140px]">{letter.attachmentName}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-mono">
                        {(letter.attachmentSize ? letter.attachmentSize / 1024 : 14.5).toFixed(1)} KB
                      </p>
                    </div>
                  </div>
                  <a
                    href={letter.attachmentData || '#'}
                    download={letter.attachmentName}
                    className="flex items-center gap-1 py-1 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] rounded-md transition-all scale-95"
                  >
                    <Download className="h-3 w-3" /> Unduh
                  </a>
                </div>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-xs text-slate-500 flex items-center gap-2 italic">
                  <Lock className="h-4 w-4 text-slate-400" /> Tidak ada lampiran fisik diunggah. Surat dikompilasi secara digital.
                </div>
              )}
            </div>

            {/* Status Penanganan (Updateable) */}
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
                Status Alur Penanganan
              </label>
              <select
                className="block w-full px-2.5 py-1.5 border border-slate-200 rounded-lg text-xs bg-slate-50 hover:bg-white text-slate-700 font-semibold focus:outline-hidden focus:ring-2 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all"
                value={status}
                onChange={(e) => setStatus(e.target.value as LetterStatus)}
              >
                <option value="diarsipkan">Diarsipkan</option>
                <option value="butuh_follow_up">Butuh Tindak Lanjut</option>
                <option value="dalam_proses">Dalam Proses</option>
                <option value="selesai">Selesai</option>
              </select>
            </div>

            {/* Disposition Catatan Pimpinan (Updateable) */}
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Catatan Disposisi Pimpinan</span>
                <span className="text-[9px] uppercase font-mono tracking-normal text-slate-400 self-end">Sifat: Kedinasan</span>
              </label>
              <textarea
                rows={3}
                className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-xs bg-slate-50/50 hover:bg-white focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-700 transition-colors"
                placeholder="Tulis disposisi lanjutan, instruksi untuk sekretariat, atau log tindakan di sini..."
                value={disposition}
                onChange={(e) => setDisposition(e.target.value)}
              />
            </div>
          </div>

          {/* Save panel changes */}
          <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[10px] text-slate-400 italic">
              * Perubahan status & disposisi langsung terekam
            </span>
            <button
              onClick={handleSaveStatusAndDisposition}
              type="button"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all hover:shadow-xs"
            >
              {isSaved ? (
                <>
                  <CheckCircle className="h-3.5 w-3.5" /> Tersimpan!
                </>
              ) : (
                'Simpan Catatan'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
