/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Mail, ArrowDownLeft, ArrowUpRight, FolderHeart, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { Letter } from '../types';

interface StatsGridProps {
  letters: Letter[];
}

export const StatsGrid: React.FC<StatsGridProps> = ({ letters }) => {
  const total = letters.length;
  const incoming = letters.filter((l) => l.type === 'masuk').length;
  const outgoing = letters.filter((l) => l.type === 'keluar').length;

  const butuhFollowUp = letters.filter((l) => l.status === 'butuh_follow_up').length;
  const dalamProses = letters.filter((l) => l.status === 'dalam_proses').length;
  const selesai = letters.filter((l) => l.status === 'selesai').length;

  return (
    <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
      {/* Total Surat */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-emerald-500/55 transition-all duration-300 shadow-black/45 hover:shadow-emerald-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total</span>
          <div className="p-1 px-2 text-[9px] font-extrabold bg-emerald-500/15 text-emerald-300 rounded-md border border-emerald-500/30 font-mono tracking-wider uppercase">Arsip</div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-white drop-shadow-[0_0_8px_rgba(16,185,129,0.2)]">{total}</span>
          <span className="text-[9px] text-emerald-400 font-mono tracking-wider uppercase">surat</span>
        </div>
      </div>

      {/* Surat Masuk */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-emerald-500/55 transition-all duration-300 shadow-black/45 hover:shadow-emerald-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Masuk</span>
          <div className="p-1 text-emerald-300 bg-emerald-500/15 border border-emerald-500/30 rounded-lg">
            <ArrowDownLeft className="h-4.5 w-4.5" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-white drop-shadow-[0_0_8px_rgba(16,185,129,0.2)]">{incoming}</span>
          <span className="text-[9px] text-emerald-400 font-mono tracking-wider uppercase">masuk</span>
        </div>
      </div>

      {/* Surat Keluar */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-emerald-500/55 transition-all duration-300 shadow-black/45 hover:shadow-emerald-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Keluar</span>
          <div className="p-1 text-emerald-300 bg-emerald-500/15 border border-emerald-500/30 rounded-lg">
            <ArrowUpRight className="h-4.5 w-4.5" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-white drop-shadow-[0_0_8px_rgba(16,185,129,0.2)]">{outgoing}</span>
          <span className="text-[9px] text-emerald-400 font-mono tracking-wider uppercase">keluar</span>
        </div>
      </div>

      {/* Butuh Tindak Lanjut */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-red-500/40 transition-all duration-300 shadow-black/45 hover:shadow-red-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tindak Lanjut</span>
          <div className="p-1 text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg">
            <ShieldAlert className="h-4.5 w-4.5" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-red-400 drop-shadow-[0_0_8px_rgba(239,68,68,0.2)]">{butuhFollowUp}</span>
          <span className="text-[9px] text-red-500 font-mono tracking-wider uppercase font-bold">butuh</span>
        </div>
      </div>

      {/* Dalam Proses */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-sky-500/40 transition-all duration-300 shadow-black/45 hover:shadow-sky-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Dalam Proses</span>
          <div className="p-1 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-lg">
            <FolderHeart className="h-4.5 w-4.5" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-sky-400 drop-shadow-[0_0_8px_rgba(56,189,248,0.2)]">{dalamProses}</span>
          <span className="text-[9px] text-sky-500 font-mono tracking-wider uppercase font-bold">proses</span>
        </div>
      </div>

      {/* Selesai */}
      <div className="bg-zinc-950/60 backdrop-blur-md p-4 rounded-xl border border-emerald-500/20 shadow-lg flex flex-col justify-between hover:border-emerald-500/55 transition-all duration-300 shadow-black/45 hover:shadow-emerald-500/5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Selesai</span>
          <div className="p-1 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-lg">
            <CheckCircle2 className="h-4.5 w-4.5" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-1.5">
          <span className="text-3xl font-extrabold font-sans tracking-tight text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.3)]">{selesai}</span>
          <span className="text-[9px] text-emerald-400 font-mono tracking-wider uppercase font-bold">selesai</span>
        </div>
      </div>
    </div>
  );
};
