/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { 
  X, 
  Plus, 
  Upload, 
  FileText, 
  Sparkles, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Check, 
  FileCheck2,
  Building2,
  UserCheck2
} from 'lucide-react';
import { Letter, LetterType, LetterPriority, LetterStatus, LETTER_CATEGORIES } from '../types';

interface LetterFormProps {
  onAddLetter: (letter: Omit<Letter, 'id'>) => void;
  onClose: () => void;
}

export const LetterForm: React.FC<LetterFormProps> = ({ onAddLetter, onClose }) => {
  const [type, setType] = useState<LetterType>('masuk');
  const [number, setNumber] = useState('');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [receivedOrSentDate, setReceivedOrSentDate] = useState(new Date().toISOString().split('T')[0]);
  const [senderOrRecipient, setSenderOrRecipient] = useState('');
  const [category, setCategory] = useState(LETTER_CATEGORIES[0]);
  const [priority, setPriority] = useState<LetterPriority>('biasa');
  const [status, setStatus] = useState<LetterStatus>('diarsipkan');
  const [disposition, setDisposition] = useState('');
  const [summary, setSummary] = useState('');
  const [signerName, setSignerName] = useState('Drs. H. Ahmad Fauzi, M.Si');
  const [signerRole, setSignerRole] = useState('Kepala Bagian Administrasi Sektoral');
  const [institutionName, setInstitutionName] = useState('Sekretariat Daerah Tata Usaha Nasional');

  // Attachment state
  const [attachmentName, setAttachmentName] = useState<string | undefined>(undefined);
  const [attachmentSize, setAttachmentSize] = useState<number | undefined>(undefined);
  const [attachmentType, setAttachmentType] = useState<string | undefined>(undefined);
  const [attachmentData, setAttachmentData] = useState<string | undefined>(undefined);
  const [isDragOver, setIsDragOver] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form field errors
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    setAttachmentName(file.name);
    setAttachmentSize(file.size);
    setAttachmentType(file.type);

    const reader = new FileReader();
    reader.onload = () => {
      // simulated storage of base64
      setAttachmentData(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Generate mock formal body based on title and category
  const handleAutoGenerateSummary = () => {
    if (!title) {
      setErrors((prev) => ({ ...prev, title: 'Masukkan perihal terlebih dahulu untuk membuat templat isi!' }));
      return;
    }
    setErrors((prev) => ({ ...prev, title: '' }));

    const cleanTitle = title.trim();
    let sampleText = '';

    if (category.includes('Undangan')) {
      sampleText = `Sehubungan dengan rencana peningkatan kinerja koordinatif regional, bersama dengan ini kami mengundang Saudara/i untuk menghadiri Rapat Koordinasi yang akan membahas perihal "${cleanTitle}".\n\nHari/Tanggal: Senin, ${date}\nWaktu: 09:00 WIB s/d Selesai\nTempat: Ruang Auditori Utama / Virtual Zoom Meeting\n\nDemikian undangan ini disampaikan, mengingat pentingnya agenda pembahasan ini, kehadiran Bapak/Ibu sangat kami harapkan tepat pada waktunya.`;
    } else if (category.includes('Keputusan')) {
      sampleText = `MEMUTUSKAN:\nMENETAPKAN:\n\nKESATU: Pemberlakuan ketetapan formal terkait perihal "${cleanTitle}" terhitung sejak tanggal dikeluarkan.\nKEDUA: Segala konsekuensi administratif, anggaran operasional, serta kewenangan pelaksana diserahkan mutlak kepada unit teknis operasional terkait.\nKETIGA: Apabila di kemudian hari terdapat kekeliruan dalam keputusan ini, akan diadakan perbaikan sebagaimana mestinya.`;
    } else if (category.includes('Keuangan')) {
      sampleText = `Berdasarkan hasil verifikasi berkas pertanggungjawaban kegiatan, terlampir rincian pengeluaran/tagihan dana senilai Rp14.500.000,- (Empat Belas Juta Lima Ratus Ribu Rupiah) untuk kepentingan "${cleanTitle}". Mohon segera dikonfirmasi kepada Bagian Perbendaharaan untuk otorisasi pencairan anggaran sebelum jatuh tempo pembayaran selanjutnya.`;
    } else if (category.includes('Kerjasama')) {
      sampleText = `Memorandum Saling Pengertian ini dibuat guna melandasi program implementasi strategis nasional terkait "${cleanTitle}". Kedua belah pihak bersepakat menyinergikan kompetensi sumber daya manusia, berbagi infrastruktur riset, serta melakukan monitoring kemajuan berkala setiap akhir caturwulan kerja terintegrasi.`;
    } else {
      sampleText = `Berkaitan dengan kelancaran tertib administrasi perkantoran, diberitahukan kepada seluruh jajaran terkait bahwa perihal "${cleanTitle}" kini telah diarsipkan secara resmi.\n\nSeluruh departemen diinstruksikan untuk menyelaraskan Standard Operating Procedure (SOP) internal sesuai dengan poin-poin petunjuk umum yang tercantum dalam lampiran dokumen terkait surat ini.`;
    }

    setSummary(sampleText);
    
    // Auto fill institution name based on type
    if (type === 'keluar' && !institutionName) {
      setInstitutionName('PT Angkasa Raya Sejahtera');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!number.trim()) newErrors.number = 'Nomor surat wajib diisi!';
    if (!title.trim()) newErrors.title = 'Perihal surat wajib diisi!';
    if (!senderOrRecipient.trim()) {
      newErrors.senderOrRecipient = type === 'masuk' ? 'Instansi pengirim wajib diisi!' : 'Instansi penerima wajib diisi!';
    }
    if (!summary.trim()) newErrors.summary = 'Ringkasan isi surat wajib diisi!';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    onAddLetter({
      number: number.trim(),
      title: title.trim(),
      date,
      receivedOrSentDate,
      senderOrRecipient: senderOrRecipient.trim(),
      category,
      type,
      priority,
      status,
      disposition: disposition.trim(),
      summary: summary.trim(),
      attachmentName,
      attachmentSize,
      attachmentType,
      attachmentData,
      signerName: signerName.trim() || undefined,
      signerRole: signerRole.trim() || undefined,
      institutionName: institutionName.trim() || undefined,
    });
  };

  return (
    <div className="bg-zinc-950/60 backdrop-blur-md rounded-xl border border-emerald-500/20 shadow-xl overflow-hidden">
      <div className="bg-zinc-900/90 px-5 py-4 border-b border-emerald-500/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1 px-2.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-lg text-xs font-bold tracking-wider uppercase">ARSIP BARU</div>
          <h2 className="text-base font-bold text-slate-100">Formulir Pengarsipan Surat</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white hover:bg-zinc-800 rounded-md transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-5">
        {/* Jenis Surat Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            Jenis Surat <span className="text-red-400">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg border text-sm font-semibold transition-all cursor-pointer ${
                type === 'masuk'
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-350 shadow-md shadow-emerald-500/10'
                  : 'bg-zinc-900/40 border-emerald-500/10 text-slate-400 hover:bg-zinc-900'
              }`}
              onClick={() => {
                setType('masuk');
                setReceivedOrSentDate(new Date().toISOString().split('T')[0]);
              }}
            >
              <ArrowDownLeft className={`h-4 w-4 ${type === 'masuk' ? 'text-emerald-400 font-bold' : 'text-slate-500'}`} />
              Surat Masuk
            </button>
            <button
              type="button"
              className={`flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg border text-sm font-semibold transition-all cursor-pointer ${
                type === 'keluar'
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-350 shadow-md shadow-emerald-500/10'
                  : 'bg-zinc-900/40 border-emerald-500/10 text-slate-400 hover:bg-zinc-900'
              }`}
              onClick={() => {
                setType('keluar');
                setReceivedOrSentDate(new Date().toISOString().split('T')[0]);
              }}
            >
              <ArrowUpRight className={`h-4 w-4 ${type === 'keluar' ? 'text-emerald-400 font-bold' : 'text-slate-500'}`} />
              Surat Keluar
            </button>
          </div>
        </div>

        {/* Nomor Surat & Kategori */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Nomor Surat <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              className={`block w-full px-3 py-2 border rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 text-slate-800 placeholder-slate-400 font-mono transition-colors ${
                errors.number ? 'border-red-300 focus:border-red-500 focus:ring-red-500/20' : 'border-slate-200 focus:border-indigo-500'
              }`}
              placeholder="Contoh: 042/UND/DISDIK/VI/2026"
              value={number}
              onChange={(e) => {
                setNumber(e.target.value);
                setErrors((prev) => ({ ...prev, number: '' }));
              }}
            />
            {errors.number && <p className="text-xs text-red-600 mt-1">{errors.number}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Klasifikasi / Kategori <span className="text-red-500">*</span>
            </label>
            <select
              className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {LETTER_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Perihal / Judul Surat */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
            Perihal / Subjek Surat <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            className={`block w-full px-3 py-2 border rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 text-slate-800 placeholder-slate-400 font-sans transition-colors ${
              errors.title ? 'border-red-300 focus:border-red-500 focus:ring-red-500/20' : 'border-slate-200 focus:border-indigo-500'
            }`}
            placeholder="Contoh: Undangan Rapat Koordinasi Akhir Tahun"
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setErrors((prev) => ({ ...prev, title: '' }));
            }}
          />
          {errors.title && <p className="text-xs text-red-600 mt-1">{errors.title}</p>}
        </div>

        {/* Asal (Masuk) / Penerima (Keluar) */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
            {type === 'masuk' ? 'Instansi Pengirim (Asal)' : 'Instansi Penerima (Tujuan)'} <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
              <Building2 className="h-4 w-4" />
            </div>
            <input
              type="text"
              className={`block w-full pl-9 pr-3 py-2 border rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 text-slate-800 placeholder-slate-400 font-sans transition-colors ${
                errors.senderOrRecipient ? 'border-red-300 focus:border-red-500 focus:ring-red-500/20' : 'border-slate-200 focus:border-indigo-500'
              }`}
              placeholder={type === 'masuk' ? 'Contoh: Dinas Kominfo Kota Gorontalo' : 'Contoh: PT Sukses Sejahera Bersama'}
              value={senderOrRecipient}
              onChange={(e) => {
                setSenderOrRecipient(e.target.value);
                setErrors((prev) => ({ ...prev, senderOrRecipient: '' }));
              }}
            />
          </div>
          {errors.senderOrRecipient && <p className="text-xs text-red-600 mt-1">{errors.senderOrRecipient}</p>}
        </div>

        {/* Tanggal Surat & Tanggal Diterima/Dikirim */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Tanggal Surat <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-800 transition-colors"
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              {type === 'masuk' ? 'Tanggal Diterima' : 'Tanggal Dikirim'} <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-800 transition-colors"
              value={receivedOrSentDate}
              onChange={(e) => setReceivedOrSentDate(e.target.value)}
            />
          </div>
        </div>

        {/* Sifat Surat (Priority) & Status Awal */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Sifat / Urgensi Surat
            </label>
            <select
              className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
              value={priority}
              onChange={(e) => setPriority(e.target.value as LetterPriority)}
            >
              <option value="biasa">Biasa (Reguler)</option>
              <option value="penting">Penting (Butuh Atensi)</option>
              <option value="sangat_penting">Sangat Penting (Mendesak)</option>
              <option value="rahasia">Rahasia / Privat</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Status Penanganan
            </label>
            <select
              className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 hover:bg-slate-50 focus:bg-white text-slate-700 font-medium focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
              value={status}
              onChange={(e) => setStatus(e.target.value as LetterStatus)}
            >
              <option value="diarsipkan">Diarsipkan Langsung</option>
              <option value="butuh_follow_up">Butuh Tindak Lanjut</option>
              <option value="dalam_proses">Sedang Dalam Proses</option>
              <option value="selesai">Selesai / Dituntaskan</option>
            </select>
          </div>
        </div>

        {/* Kop Surat Header Details (For simulation preview) */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
            <Building2 className="h-3.5 w-3.5 text-indigo-500" /> Detail Kop & Pengesahan Surat (Untuk Simulasi Cetak)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Kop Instansi Utama
              </label>
              <input
                type="text"
                className="block w-full px-2 py-1.5 border border-slate-200 rounded bg-white text-xs text-slate-700 font-medium focus:outline-hidden focus:border-indigo-500"
                placeholder="Sekretariat Tata Usaha"
                value={institutionName}
                onChange={(e) => setInstitutionName(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Nama Penandatangan
              </label>
              <input
                type="text"
                className="block w-full px-2 py-1.5 border border-slate-200 rounded bg-white text-xs text-slate-700 font-medium focus:outline-hidden focus:border-indigo-500"
                placeholder="Drs. H. Ahmad Fauzi"
                value={signerName}
                onChange={(e) => setSignerName(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
                Jabatan Penandatangan
              </label>
              <input
                type="text"
                className="block w-full px-2 py-1.5 border border-slate-200 rounded bg-white text-xs text-slate-700 font-medium focus:outline-hidden focus:border-indigo-500"
                placeholder="Kepala Bagian Kepegawaian"
                value={signerRole}
                onChange={(e) => setSignerRole(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Ringkasan Surat & Autogenerator */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Ringkasan Isi / Teks Surat <span className="text-red-500">*</span>
            </label>
            <button
              type="button"
              className="text-[11px] font-bold text-indigo-700 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 py-1 px-2.5 rounded-md hover:bg-indigo-100 transition-colors"
              onClick={handleAutoGenerateSummary}
              title="Isi otomatis konten formal berdasarkan perihal"
            >
              <Sparkles className="h-3 w-3" /> Templat Isi Formal
            </button>
          </div>
          <textarea
            rows={4}
            className={`block w-full px-3 py-2 border rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 text-slate-800 placeholder-slate-400 font-sans transition-colors ${
              errors.summary ? 'border-red-300 focus:border-red-500 focus:ring-red-500/20' : 'border-slate-200 focus:border-indigo-500'
            }`}
            placeholder="Ketik isi singkat surat, petunjuk disposisi utama, atau ringkasan dokumen di sini..."
            value={summary}
            onChange={(e) => {
              setSummary(e.target.value);
              setErrors((prev) => ({ ...prev, summary: '' }));
            }}
          />
          {errors.summary && <p className="text-xs text-red-600 mt-1">{errors.summary}</p>}
        </div>

        {/* Disposisi Catatan Awal (Optional) */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
            Instruksi Disposisi / Catatan Internal <span className="text-slate-400 text-[10px]">(Opsional)</span>
          </label>
          <input
            type="text"
            className="block w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-slate-50/50 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 text-slate-800 placeholder-slate-400 transition-colors"
            placeholder="Petunjuk lanjutan, e.g., 'Harap koordinasikan dengan tim keuangan terkait pembayaran'"
            value={disposition}
            onChange={(e) => setDisposition(e.target.value)}
          />
        </div>

        {/* Drag and Drop File Attachment */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
            Lampiran Berkas Digital / Dokumen Pendukung <span className="text-slate-400 text-[10px]">(Opsional)</span>
          </label>
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
              isDragOver
                ? 'border-indigo-500 bg-indigo-50/40'
                : attachmentName
                ? 'border-emerald-300 bg-emerald-50/20'
                : 'border-slate-200 bg-slate-50/30 hover:bg-slate-50/70 hover:border-slate-300'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
            />
            {attachmentName ? (
              <div className="flex flex-col items-center justify-center">
                <div className="p-2.5 bg-emerald-100 text-emerald-800 rounded-full mb-2">
                  <FileCheck2 className="h-6 w-6" />
                </div>
                <p className="text-xs font-semibold text-slate-700">{attachmentName}</p>
                <p className="text-[10px] text-slate-500 mt-1 font-mono">
                  {(attachmentSize ? attachmentSize / 1024 : 0).toFixed(1)} KB &bull;{' '}
                  {attachmentType || 'Berkas digital'}
                </p>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setAttachmentName(undefined);
                    setAttachmentSize(undefined);
                    setAttachmentType(undefined);
                    setAttachmentData(undefined);
                  }}
                  className="mt-2 text-xs font-bold text-red-600 hover:text-red-700"
                >
                  Hapus Berkas Lumatan
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center">
                <div className="p-2.5 bg-slate-100 text-slate-500 rounded-full mb-2">
                  <Upload className="h-6 w-6" />
                </div>
                <p className="text-xs font-semibold text-slate-600">
                  <span className="text-indigo-600 hover:underline">Pilih berkas</span> atau seret kemari
                </p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Mendukung PDF, PNG, JPG, Word hingga 25MB (disimpan lokal)
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 rounded-lg text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-colors"
          >
            Batal
          </button>
          <button
            type="submit"
            className="px-5 py-2 bg-indigo-600 border border-indigo-700 text-white rounded-lg text-sm font-bold flex items-center gap-1.5 hover:bg-indigo-700 hover:shadow-xs transition-all cursor-pointer"
          >
            <Plus className="h-4.5 w-4.5" /> Arsipkan Surat
          </button>
        </div>
      </form>
    </div>
  );
};
