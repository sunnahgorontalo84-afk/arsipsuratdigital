import React, { useState } from 'react';
import { 
  School, 
  Lock, 
  User, 
  LogIn, 
  Eye, 
  EyeOff, 
  FolderLock, 
  ShieldAlert,
  BookOpen
} from 'lucide-react';

interface AdminLoginProps {
  onLoginSuccess: (username: string) => void;
}

export function AdminLogin({ onLoginSuccess }: AdminLoginProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Default credentials
  const defaultUser = 'admin';
  const defaultPass = 'madrasah123';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    // Minor timeout to give realistic experience
    setTimeout(() => {
      if (username.trim().toLowerCase() === defaultUser && password === defaultPass) {
        onLoginSuccess(username);
      } else {
        setError('Nama Pengguna (Username) atau Kata Sandi salah. Silakan coba lagi.');
        setIsLoading(false);
      }
    }, 850);
  };

  return (
    <div id="login-container" className="min-h-screen bg-neutral-950 text-slate-100 flex flex-col justify-center items-center px-4 relative overflow-hidden font-sans">
      {/* Decorative Orbuluating background gradient */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-[250px] h-[250px] bg-teal-500/5 rounded-full blur-[80px] pointer-events-none" />

      <div className="w-full max-w-md z-10 space-y-6">
        
        {/* Top Header Logos & Branding */}
        <div className="text-center space-y-3">
          <div className="inline-flex p-3.5 bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-2xl shadow-xl shadow-emerald-500/10 ring-4 ring-emerald-500/10 animate-fade-in">
            <School className="h-8 w-8 stroke-2" />
          </div>
          <div className="space-y-1">
            <h1 className="text-3xl font-extrabold tracking-tight font-display bg-clip-text bg-gradient-to-r from-slate-50 via-emerald-100 to-slate-200">
              PORTAL MADRASAH
            </h1>
            <p className="text-xs text-emerald-400 font-bold uppercase tracking-widest">
              Tata Usaha & Kearsipan Digital
            </p>
          </div>
          <p className="text-sm text-slate-450 max-w-xs mx-auto">
            Sistem pengarsipan, disposisi, dan pembuatan format surat elektronik terakreditasi formal.
          </p>
        </div>

        {/* Login Glass Panel Form Card */}
        <div className="glass-panel p-8 shadow-[0_12px_40px_rgba(0,0,0,0.6)] relative overflow-hidden border border-emerald-500/20 backdrop-blur-md bg-zinc-950/65 rounded-2xl">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-600" />
          
          <h2 className="text-lg font-bold text-slate-100 mb-6 flex items-center gap-2">
            <FolderLock className="h-5 w-5 text-emerald-400" />
            <span>Autentikasi Admin TU</span>
          </h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <div className="p-3.5 bg-red-500/10 border border-red-500/30 text-xs font-semibold text-red-300 rounded-lg flex items-start gap-2 animate-fade-in">
                <ShieldAlert className="h-4.5 w-4.5 text-red-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {/* Username Input */}
            <div>
              <label 
                htmlFor="username" 
                className="block text-[11px] font-bold text-slate-455 uppercase tracking-wider mb-2 font-sans"
              >
                Nama Pengguna
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-450 pointer-events-none">
                  <User className="h-4 w-4 text-emerald-500/60" />
                </span>
                <input
                  id="username"
                  type="text"
                  required
                  placeholder="admin"
                  className="block w-full pl-10 pr-3 py-2.5 bg-zinc-900 border border-emerald-500/15 rounded-xl text-sm text-slate-100 placeholder-slate-500 font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/25 transition-all"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label 
                  htmlFor="password" 
                  className="block text-[11px] font-bold text-slate-455 uppercase tracking-wider font-sans"
                >
                  Kata Sandi
                </label>
              </div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-450 pointer-events-none">
                  <Lock className="h-4 w-4 text-emerald-500/60" />
                </span>
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  placeholder="••••••••"
                  className="block w-full pl-10 pr-10 py-2.5 bg-zinc-900 border border-emerald-500/15 rounded-xl text-sm text-slate-100 placeholder-slate-500 font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/25 transition-all"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white transition-colors cursor-pointer"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Login Action Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 disabled:cursor-not-allowed text-white text-xs font-bold uppercase tracking-widest rounded-xl transition-all shadow-lg hover:shadow-emerald-500/10 flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 border-2 border-slate-300 border-t-white rounded-full animate-spin" />
                  <span>Memverifikasi...</span>
                </div>
              ) : (
                <>
                  <LogIn className="h-4 w-4" />
                  <span>Masuk ke Database</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Informational Box with default credentials inside the form */}
          <div className="mt-6 pt-5 border-t border-emerald-550/10">
            <div className="p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10 space-y-1.5 text-left">
              <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-300 uppercase tracking-wide">
                <BookOpen className="h-3.5 w-3.5" /> Akun Demo Madrasah
              </div>
              <div className="text-[11px] text-slate-400 space-y-0.5 leading-relaxed font-sans">
                <p>Silakan gunakan kredensial bawaan berikut untuk masuk:</p>
                <div className="font-mono text-[10px] text-emerald-400/90 mt-1 bg-black/40 p-1.5 rounded-md border border-emerald-500/5 space-y-0.5">
                  <div>User Name: <span className="text-white font-bold">admin</span></div>
                  <div>Password: <span className="text-white font-bold">madrasah123</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Credit */}
        <div className="text-center text-[11px] text-slate-500 font-medium">
          <p>Sistem Kearsipan Mandiri Madrasah &copy; 2026</p>
          <p className="mt-0.5 text-emerald-500/40 text-[9px] uppercase tracking-widest font-bold">Offline-First Secure Sandbox</p>
        </div>
      </div>
    </div>
  );
}
