/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  ArrowDownLeft, 
  ArrowUpRight, 
  Calendar, 
  ChevronUp, 
  ChevronDown, 
  FileText, 
  Eye, 
  Trash2, 
  Paperclip,
  Inbox
} from 'lucide-react';
import { Letter, PRIORITY_CONFIG, STATUS_CONFIG } from '../types';

interface LetterTableProps {
  letters: Letter[];
  onSelectLetter: (l: Letter) => void;
  onDeleteLetter: (id: string) => void;
  selectedLetterId?: string;
}

type SortField = 'date' | 'number' | 'title' | 'senderOrRecipient';
type SortOrder = 'asc' | 'desc';

export const LetterTable: React.FC<LetterTableProps> = ({
  letters,
  onSelectLetter,
  onDeleteLetter,
  selectedLetterId,
}) => {
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const sortedLetters = [...letters].sort((a, b) => {
    let comparison = 0;
    if (sortField === 'date') {
      comparison = a.date.localeCompare(b.date);
    } else if (sortField === 'number') {
      comparison = a.number.localeCompare(b.number);
    } else if (sortField === 'title') {
      comparison = a.title.localeCompare(b.title);
    } else if (sortField === 'senderOrRecipient') {
      comparison = a.senderOrRecipient.localeCompare(b.senderOrRecipient);
    }
    return sortOrder === 'asc' ? comparison : -comparison;
  });

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortOrder === 'asc' ? (
      <ChevronUp className="h-4 w-4 inline-block text-slate-800 ml-1" />
    ) : (
      <ChevronDown className="h-4 w-4 inline-block text-slate-800 ml-1" />
    );
  };

  if (letters.length === 0) {
    return (
      <div className="bg-zinc-950/60 backdrop-blur-md rounded-xl border border-emerald-500/20 p-12 text-center flex flex-col items-center justify-center shadow-xl">
        <div className="p-4 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full mb-4">
          <Inbox className="h-10 w-10 stroke-1" />
        </div>
        <h3 className="text-base font-bold text-slate-100">Tidak ada arsip ditemukan</h3>
        <p className="text-xs text-slate-400 mt-1.5 max-w-sm">
          Semua filter kosong atau tidak ada surat yang sesuai dengan kriteria pencarian Anda.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-zinc-950/60 backdrop-blur-md rounded-xl border border-emerald-500/20 shadow-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-zinc-900/90 border-b border-emerald-500/20 text-[10px] font-bold text-emerald-400 uppercase tracking-widest">
              <th className="py-3.5 px-4 w-28 text-center">Jenis</th>
              <th className="py-3.5 px-4 cursor-pointer hover:bg-zinc-800/80 transition-colors" onClick={() => handleSort('number')}>
                Nomor Surat <SortIcon field="number" />
              </th>
              <th className="py-3.5 px-4 cursor-pointer hover:bg-zinc-800/80 transition-colors" onClick={() => handleSort('title')}>
                Perihal / Judul & Kategori <SortIcon field="title" />
              </th>
              <th className="py-3.5 px-4 cursor-pointer hover:bg-zinc-800/80 transition-colors" onClick={() => handleSort('senderOrRecipient')}>
                Asal / Penerima <SortIcon field="senderOrRecipient" />
              </th>
              <th className="py-3.5 px-4 cursor-pointer hover:bg-zinc-800/80 transition-colors w-32" onClick={() => handleSort('date')}>
                Tanggal <SortIcon field="date" />
              </th>
              <th className="py-3.5 px-4 w-28 text-center">Sifat</th>
              <th className="py-3.5 px-4 w-32 text-center">Status</th>
              <th className="py-3.5 px-4 w-24 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-emerald-500/10 text-xs text-slate-300">
            {sortedLetters.map((l) => {
              const priority = PRIORITY_CONFIG[l.priority] || PRIORITY_CONFIG.biasa;
              const status = STATUS_CONFIG[l.status] || STATUS_CONFIG.diarsipkan;
              const isSelected = selectedLetterId === l.id;

              return (
                <tr
                  key={l.id}
                  className={`group hover:bg-emerald-500/5 transition-all duration-200 cursor-pointer ${
                    isSelected ? 'bg-emerald-500/10 hover:bg-emerald-500/15 border-l-4 border-l-emerald-500' : ''
                  }`}
                  onClick={() => onSelectLetter(l)}
                >
                  {/* Jenis */}
                  <td className="py-4 px-4 text-center">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold tracking-wider uppercase ${
                        l.type === 'masuk'
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/25'
                          : 'bg-emerald-600/15 text-emerald-300 border border-emerald-500/25'
                      }`}
                    >
                      {l.type === 'masuk' ? (
                        <>
                          <ArrowDownLeft className="h-3 w-3 text-emerald-400" />
                          Masuk
                        </>
                      ) : (
                        <>
                          <ArrowUpRight className="h-3 w-3 text-emerald-400" />
                          Keluar
                        </>
                      )}
                    </span>
                  </td>

                  {/* Nomor Surat */}
                  <td className="py-4 px-4 font-mono font-medium text-[11px] text-emerald-300 break-all">
                    {l.number}
                  </td>

                  {/* Title & Category */}
                  <td className="py-4 px-4 max-w-xs md:max-w-md">
                    <div className="font-bold text-slate-150 group-hover:text-emerald-400 transition-colors line-clamp-1">
                      {l.title}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-1 font-medium flex items-center gap-1.5">
                      <span className="bg-zinc-900 border border-emerald-500/15 text-slate-300 px-1.5 py-0.5 rounded-sm scale-95 font-semibold text-[9px] uppercase tracking-wider">
                        {l.category}
                      </span>
                      {l.attachmentName && (
                        <span className="text-slate-400 flex items-center gap-0.5 text-[9px]">
                          <Paperclip className="h-3 w-3 text-emerald-400" /> Web_PDF
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Asal / Penerima */}
                  <td className="py-4 px-4 text-xs font-medium text-slate-300">
                    <div className="line-clamp-2">{l.senderOrRecipient}</div>
                  </td>

                  {/* Tanggal */}
                  <td className="py-4 px-4 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-300 font-medium font-mono">
                      <Calendar className="h-3.5 w-3.5 text-emerald-400/75" />
                      {l.date}
                    </div>
                    {l.receivedOrSentDate && l.receivedOrSentDate !== l.date && (
                      <div className="text-[9px] text-slate-400 mt-0.5 italic pl-5 font-mono">
                        {l.type === 'masuk' ? 'Diterima' : 'Dikirim'}: {l.receivedOrSentDate}
                      </div>
                    )}
                  </td>

                  {/* Sifat */}
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-block text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-sm border ${priority.color}`}>
                      {priority.label}
                    </span>
                  </td>

                  {/* Status */}
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[10px] font-extrabold uppercase ring-1 ring-inset ${status.color}`}>
                      {status.label}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="py-4 px-4 text-center" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => onSelectLetter(l)}
                        className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-md transition-colors"
                        title="Buka Lembar Disposisi & Preview"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => onDeleteLetter(l.id)}
                        className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-md transition-colors"
                        title="Hapus Arsip"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <div className="bg-zinc-900 border-t border-emerald-500/15 py-3.5 px-4 flex items-center justify-between text-xs text-slate-400 font-medium font-sans">
        <div>
          Menampilkan <span className="font-bold text-slate-200">{letters.length}</span> surat arsip
        </div>
        <div>
          Kombinasi <span className="font-mono text-emerald-400 font-bold">ID-Arsip</span> dienkripsi aman secara lokal
        </div>
      </div>
    </div>
  );
};
