import React, { useState, useRef, useEffect } from 'react';
import { 
  X, 
  Sparkles, 
  PenTool, 
  QrCode, 
  Building2, 
  Settings, 
  FileText, 
  ChevronRight, 
  RotateCcw, 
  Check, 
  Trash2,
  Bookmark,
  Calendar,
  User,
  ShieldCheck,
  Languages,
  LayoutTemplate,
  Upload
} from 'lucide-react';
import { Letter, LetterType, LetterPriority, LetterStatus, LETTER_CATEGORIES } from '../types';

const PRESET_TEMPLATES: Record<string, { title: string; category: string; description: string; content: string }> = {
  kemenag: {
    title: 'Penyampaian Laporan Pertanggungjawaban BOP Madrasah',
    category: 'Surat ke Kemenag',
    description: 'Templat resmi pertanggungjawaban BOP/keuangan kepada Kanwil Kemenag.',
    content: `Nomor: B-[Nomor_Surat]/Madrasah.MA/PP.00/V/2026
Sifat: Penting
Lampiran: 1 Berkas LPJ BOP
Perihal: Laporan Pertanggungjawaban Bantuan Operasional Pendidikan Madrasah

Kepada Yth,
Kepala Kantor Wilayah Kementerian Agama Provinsi Gorontalo
u.p. Kepala Bidang Pendidikan Madrasah / Keagamaan Islam
di Tempat

Assalamu'alaikum Wr. Wb.

Dengan hormat, sehubungan dengan penyaluran dana Bantuan Operasional Pendidikan (BOP) Madrasah Aliyah Negeri Digital Semester Ganjil Tahun Anggaran 2026, bersama ini kami sampaikan berkas Laporan Pertanggungjawaban (LPJ) Penggunaan Dana Tahap Pertama secara lengkap dan akuntabel.

Laporan ini menyertakan:
1. Rencana Kegiatan dan Anggaran Madrasah (RKAM) Perubahan
2. Surat Pernyataan Tanggung Jawab Belanja (SPTJB)
3. Rekapitulasi Realisasi Pengeluaran Kas dan bukti dukung kuitansi fisik
4. Berita Acara Pemeriksaan Kas Madrasah

Adapun dana tersebut telah kami realisasikan dengan prioritas peningkatan mutu pembelajaran para siswa, penyediaan instrumen ajar digital terakreditasi, serta pemeliharaan sarana prasarana penunjang praktikum komputer madrasah.

Demikian laporan pertanggungjawaban ini disampaikan sebagai bentuk komitmen transparansi tata kelola internal madrasah kami. Atas perhatian, arahan, dan bimbingan Bapak Kepala Kanwil, kami haturkan terima kasih.

Wassalamu'alaikum Wr. Wb.`
  },
  siswa: {
    title: 'Surat Rekomendasi Pendaftaran Beasiswa Indonesia Prestasi Kesiswaan',
    category: 'Siswa / Kesiswaan',
    description: 'Rekomendasi beasiswa untuk siswa berprestasi & berkarakter unggul.',
    content: `Nomor: [Nomor_Surat]/S.Kes/MA-DI/IV/2026
Sifat: Biasa
Perihal: Surat Rekomendasi Beasiswa Prestasi Unggul Madrasah

Kepada Yth,
Ketua Komite Seleksi Program Beasiswa Indonesia Cerdas
di Jakarta

Assalamu'alaikum Wr. Wb.

Kepala Madrasah Aliyah Negeri Digital Gorontalo dengan ini memberikan rekomendasi formal kepada siswa berprestasi di bawah ini:

Nama Lengkap : [Nama Siswa]
NIS / NISN   : [Nomor Induk Siswa]
Kelas        : [Kelas Siswa]
Program      : [Peminatan MIPA/IPS/Keagamaan]

Bahwasanya yang bersangkutan adalah benar siswa aktif berkinerja unggul di madrasah kami, berkelakuan sangat baik, serta menunjukkan dedikasi akademik tinggi dengan peringkat 3 (tiga) besar umum dalam evaluasi semester terakhir. Siswa tersebut juga aktif dalam organisasi kemanusiaan kepanduan Pramuka serta menorehkan prestasi medali perak pada Olimpiade Sains Madrasah tingkat provinsi.

Kami sangat merekomendasikan siswa ini untuk menerima beasiswa penunjang guna kelanjutan pendidikan beliau di kancah akademi tinggi nasional.

Demikian rekomendasi ini dibuat dengan sebenar-benarnya untuk dipergunakan sebagai bahan pertimbangan positif dan pemenuhan syarat administratif pendaftaran beasiswa. Terima kasih banyak.

Wassalamu'alaikum Wr. Wb.`
  },
  legalisir: {
    title: 'Surat Keterangan Pengesahan Salinan Ijazah Terkait Verifikasi Data Induk',
    category: 'Legalisir',
    description: 'Validasi kesahihan nomor seri ijazah alumni sesuai buku klapper TU.',
    content: `Nomor: [Nomor_Surat]/LEG-MA/V/2026
Perihal: Surat Keterangan Pengesahan Salinan Ijazah (Legalisir)

Kepada Yth,
Kepala Dinas Kepegawaian dan Pengembangan Sumber Daya Manusia (BKPSDM)
di Tempat

Assalamu'alaikum Wr. Wb.

Yang bertandatangan di bawah ini, Kepala Urusan Tata Usaha Madrasah Aliyah Negeri Digital Gorontalo menerangkan bahwa:

Nama Alumni   : [Nama Alumni]
Tahun Lulus   : [Tahun Kelulusan]
Nomor Ijazah : [Nomor Seri Ijazah]

Telah mengajukan permohonan pengesahan (legalisir) dokumen salinan ijazah asli kelulusan madrasah untuk kebutuhan administratif seleksi penempatan kerja / CPNS daerah. Kami menerangkan bahwa setelah dilakukan verifikasi silang pada Buku Klapper Induk Alumni bertanggal kelulusan yang bersangkutan, dokumen salinan tersebut sepenuhnya COCOK, BENAR, dan SAH sesuai berkas induk di database kearsipan madrasah kami.

Demikian surat pengesahan legalisir ini diterbitkan secara resmi agar dapat dipergunakan sebagaimana mestinya dengan penuh rasa tanggung jawab.

Wassalamu'alaikum Wr. Wb.`
  }
};

interface LetterCreatorProps {
  onAddLetter: (letter: Omit<Letter, 'id'>) => void;
  onClose: () => void;
}

export const LetterCreator: React.FC<LetterCreatorProps> = ({ onAddLetter, onClose }) => {
  // Creator Page Sub-steps
  const [activeStep, setActiveStep] = useState<'kop' | 'konten' | 'ttd'>('kop');

  // Kop (Letterhead) State
  const [logoSymbol, setLogoSymbol] = useState<'garuda' | 'bintang' | 'daun' | 'global' | 'none' | 'custom'>('custom');
  const [customLogoUrl, setCustomLogoUrl] = useState<string | undefined>(undefined);
  const [kopFontFamily, setKopFontFamily] = useState<string>("'Times New Roman', Times, serif");
  const [instansiUtama, setInstansiUtama] = useState('PEMERINTAH KOTA GORONTALO');
  const [instansiSub, setInstansiSub] = useState('DINAS KOMUNIKASI INFORMATIKA DAN PERSANDIAN');
  const [alamat, setAlamat] = useState('Jl. Jend. Sudirman No. 12, Gorontalo, 96115');
  const [kontak, setKontak] = useState('Telp: (0435) 821156 | Email: diskominfo@gorontalokota.go.id | Web: gorontalokota.go.id');

  // Metadata State
  const [type, setType] = useState<LetterType>('keluar');
  const [number, setNumber] = useState(`045/DKIP-GTLO/${new Date().getFullYear()}`);
  const [category, setCategory] = useState('Pemberitahuan / Edaran');
  const [priority, setPriority] = useState<LetterPriority>('penting');
  const [title, setTitle] = useState('');
  const [senderOrRecipient, setSenderOrRecipient] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  // Content state
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiContext, setAiContext] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [summary, setSummary] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Digital Signature State
  const [signatureMode, setSignatureMode] = useState<'draw' | 'qr' | 'upload'>('draw');
  const [signerName, setSignerName] = useState('Ir. H. Syarifudin Noer, M.Si');
  const [signerRole, setSignerRole] = useState('Kepala Dinas Komunikasi & Informatika');
  const [signerId, setSignerId] = useState('NIP. 19801124 200604 1 003');
  const [inkColor, setInkColor] = useState<string>('#1e3a8a'); // Dark blue ink default
  const [penWidth, setPenWidth] = useState<number>(3);
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | undefined>(undefined);
  const [uploadedSignatureUrl, setUploadedSignatureUrl] = useState<string | undefined>(undefined);

  // Canvas Reference
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Re-draw grid on canvas initialization
  useEffect(() => {
    if (signatureMode === 'draw' && activeStep === 'ttd') {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.strokeStyle = inkColor;
          ctx.lineWidth = penWidth;
          ctx.lineCap = 'round';
          ctx.lineJoin = 'round';
        }
      }
    }
  }, [signatureMode, activeStep, inkColor, penWidth]);

  // Canvas Drawing Handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);

    // Disable scrolling when drawing on touchscreen
    if (e.cancelable) {
      e.preventDefault();
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();

    if (e.cancelable) {
      e.preventDefault();
    }
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureDataUrl(undefined);
  };

  const saveCanvasSignature = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      // Check if canvas is empty
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      
      const dataUrl = canvas.toDataURL('image/png');
      setSignatureDataUrl(dataUrl);
    }
  };

  // Automated content generation using server endpoint (Express + Vite)
  const handleAutoGenerateContent = async () => {
    if (!title) {
      alert('Masukkan perihal / subjek surat terlebih dahulu!');
      return;
    }

    setIsGenerating(true);
    setErrorMessage(null);

    try {
      const response = await fetch('/api/generate-letter', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title,
          category,
          sender: instansiUtama + ' - ' + instansiSub,
          recipient: senderOrRecipient || '(Instansi Penerima)',
          context: aiPrompt + ' ' + aiContext
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Server error saat membuat surat.');
      }

      const res = await response.json();
      if (res.text) {
        setSummary(res.text);
      } else {
        throw new Error('Hasil respons kosong');
      }
    } catch (err: any) {
      console.warn("Gemini Server generation failed, falling back to local template:", err);
      setErrorMessage("Kunci API Gemini tidak terdeteksi atau bermasalah. Menggunakan mesin templat cerdas lokal.");
      generateLocalSmartTemplate();
    } finally {
      setIsGenerating(false);
    }
  };

  const generateLocalSmartTemplate = () => {
    const cleanTitle = title || "Kerjasama Program Sektoral";
    const cleanRecipient = senderOrRecipient || "Pimpinan Mitra Kerja Utama";
    
    let text = `Dengan hormat,

Sehubungan dengan upaya menyukseskan implementasi kerja kolaboratif sektoral yang berkelanjutan, bersama ini kami sampaikan penjelasan serta pengajuan kerja sama resmi terkait perihal "${cleanTitle}".

Kami memandang bahwa sinergi operasional antara kami selaku pihak pengirim bersama dengan jajaran pimpinan ${cleanRecipient} selaku mitra kerja strategis nasional memiliki potensi yang bernilai tinggi guna kelancaran pelayanan administrasi publik kemasyarakatan.

Adapun kriteria, prasyarat, ketentuan teknis, serta agenda diskusi pendahuluan yang komprehensif telah kami lampirkan bersama di dalam lembar suplemen digital tak terpisahkan dari surat permohonan ini. 

Demikian pengajuan permohonan ini disampaikan. Besar harapan kami kiranya Bapak/Ibu pimpinan berkenan memberikan atensi, pertimbangan positif, serta koordinasi lanjutan dalam waktu yang tidak terlalu lama.Atas perhatian serta jalinan kerja sama yang baik, kami haturkan limpah terima kasih.

Hormat kami,`;
    setSummary(text);
  };

  const handleLoadPresetTemplate = (key: string) => {
    const preset = PRESET_TEMPLATES[key];
    if (preset) {
      setTitle(preset.title);
      setCategory(preset.category);
      setSummary(preset.content);
    }
  };

  const handleUploadTemplate = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result;
      if (typeof content === 'string') {
        try {
          if (file.name.endsWith('.json')) {
            const parsed = JSON.parse(content);
            if (parsed.summary || parsed.content) {
              setSummary(parsed.summary || parsed.content);
              if (parsed.title) setTitle(parsed.title);
              if (parsed.category) setCategory(parsed.category);
              if (parsed.number) setNumber(parsed.number);
              if (parsed.senderOrRecipient) setSenderOrRecipient(parsed.senderOrRecipient);
              alert('Templat JSON berhasil dimuat!');
            } else {
              setSummary(content);
              alert('Berkas JSON dimuat sebagai teks mentah.');
            }
          } else {
            setSummary(content);
            alert('Berkas templat teks berhasil diunggah!');
          }
        } catch (err) {
          setSummary(content);
          alert('Teks templat berhasil dimuat.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handlePublishLetterToArchive = () => {
    if (!number || !title || !senderOrRecipient || !summary) {
      alert('Nomor Surat, Perihal, Instansi Pengirim/Penerima, dan Isi Utama Surat wajib diisi!');
      return;
    }

    // Capture drawn signature if in draw mode
    let ttdUrlUrl = signatureDataUrl;
    if (signatureMode === 'draw' && !ttdUrlUrl) {
      const canvas = canvasRef.current;
      if (canvas) {
        // Quick check
        ttdUrlUrl = canvas.toDataURL('image/png');
      }
    } else if (signatureMode === 'upload') {
      ttdUrlUrl = uploadedSignatureUrl;
    }

    onAddLetter({
      number,
      title,
      date,
      receivedOrSentDate: date,
      senderOrRecipient,
      category,
      type,
      priority,
      status: 'diarsipkan',
      summary,
      disposition: 'Telah terdaftar secara digital di sistem kearsipan dan disetujui pimpinan melalui tanda tangan elektronik terdaftar.',
      signerName,
      signerRole,
      institutionName: instansiSub || instansiUtama,
      attachmentName: ttdUrlUrl ? 'Lembar_Signature_Digital.png' : undefined,
      attachmentSize: ttdUrlUrl ? Math.round(ttdUrlUrl.length * 0.75) : undefined,
      attachmentType: ttdUrlUrl ? 'image/png' : undefined,
      attachmentData: ttdUrlUrl, // storing signature in attachmentData for rendering!
      kopLogoUrl: logoSymbol === 'custom' ? customLogoUrl : logoSymbol,
      kopFontFamily: kopFontFamily
    });
  };

  // Render SVG Logo preview based on select
  const renderLogo = () => {
    switch (logoSymbol) {
      case 'custom':
        if (customLogoUrl) {
          return (
            <img 
              src={customLogoUrl} 
              alt="Custom Logo" 
              className="h-11 w-11 object-contain rounded-md border border-emerald-500/20 shadow-xs shrink-0 bg-white" 
              referrerPolicy="no-referrer"
            />
          );
        }
        return (
          <div className="h-10 w-10 flex items-center justify-center bg-zinc-850 text-emerald-300 rounded-md font-extrabold text-[10px] shrink-0 border border-dashed border-emerald-500/30">
            LOGO
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="bg-zinc-950/60 backdrop-blur-md rounded-xl border border-emerald-500/20 shadow-xl overflow-hidden">
      {/* Top title bar */}
      <div className="bg-zinc-900 text-white px-5 py-4 border-b border-emerald-500/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1 px-2.5 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 rounded-lg text-xs font-bold flex items-center gap-1">
            <LayoutTemplate className="h-3.5 w-3.5" /> DOKUMEN GENERATOR
          </div>
          <h2 className="text-base font-bold text-slate-100">Pembuat Format & Surat Resmi Mandiri</h2>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white hover:bg-zinc-800 rounded-md transition-colors cursor-pointer"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Guided Steps indicator */}
      <div className="bg-zinc-900/60 border-b border-emerald-500/15 grid grid-cols-3 text-center text-xs font-bold py-3 divide-x divide-emerald-500/10 text-slate-400">
        <button
          type="button"
          onClick={() => setActiveStep('kop')}
          className={`px-4 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeStep === 'kop' ? 'text-emerald-300 font-black bg-zinc-900/95 shadow-inner' : 'text-slate-400 hover:text-emerald-400'
          }`}
        >
          <Building2 className={`h-4 w-4 ${activeStep === 'kop' ? 'text-emerald-450' : 'text-slate-500'}`} />
          <span>1. Format Kop & Instansi</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveStep('konten')}
          className={`px-4 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeStep === 'konten' ? 'text-emerald-300 font-black bg-zinc-900/95 shadow-inner' : 'text-slate-400 hover:text-emerald-400'
          }`}
        >
          <Sparkles className={`h-4 w-4 ${activeStep === 'konten' ? 'text-emerald-450' : 'text-slate-500'}`} />
          <span>2. AI Auto-Isi Surat</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveStep('ttd')}
          className={`px-4 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            activeStep === 'ttd' ? 'text-emerald-300 font-black bg-zinc-900/95 shadow-inner' : 'text-slate-400 hover:text-emerald-400'
          }`}
        >
          <PenTool className={`h-4 w-4 ${activeStep === 'ttd' ? 'text-emerald-450' : 'text-slate-500'}`} />
          <span>3. Tanda Tangan Digital</span>
        </button>
      </div>

      <div className="p-6">
        {/* STEP 1: KOP SURAT AND INSTANSI SETUP */}
        {activeStep === 'kop' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Kop Config */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-emerald-500/10 pb-2">
                  <Settings className="h-4 w-4 text-emerald-400" /> Detail Kop Resmi
                </h3>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-slate-400 uppercase">Lambang Instansi / Logo</label>
                    {customLogoUrl && (
                      <button
                        type="button"
                        onClick={() => setCustomLogoUrl(undefined)}
                        className="text-[10px] text-red-400 hover:text-red-300 font-bold underline cursor-pointer"
                      >
                        Hapus Logo
                      </button>
                    )}
                  </div>
                  <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg animate-fade-in">
                    <input
                      type="file"
                      accept="image/*"
                      className="block w-full text-xs text-slate-350 file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border file:border-emerald-500/20 file:text-xs file:font-bold file:bg-emerald-500/15 file:text-emerald-300 hover:file:bg-emerald-500/25 cursor-pointer font-sans"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onloadend = () => {
                            setCustomLogoUrl(reader.result as string);
                          };
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                    <p className="text-[10px] text-slate-400 mt-1.5 leading-tight">
                      Mendukung format PNG / JPG dengan latar transparan atau putih (Otomatis diskalakan).
                    </p>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Gaya Font Kop Surat</label>
                  <select
                    className="block w-full px-3 py-2 border border-emerald-500/20 rounded-lg text-sm bg-zinc-900 text-slate-100 font-medium focus:outline-hidden focus:border-emerald-500"
                    value={kopFontFamily}
                    onChange={(e) => setKopFontFamily(e.target.value)}
                  >
                    <option value="'Times New Roman', Times, serif" className="bg-zinc-950 text-slate-100">Times New Roman (Serif Tradisional Resmi)</option>
                    <option value="'Georgia', serif" className="bg-zinc-950 text-slate-100">Georgia (Serif Elegan & Berkelas)</option>
                    <option value="system-ui, -apple-system, sans-serif" className="bg-zinc-950 text-slate-100">Inter / System Sans (Modern & Bersih)</option>
                    <option value="'Courier New', Courier, monospace" className="bg-zinc-950 text-slate-100">Courier New (Klasik Mesin Tik)</option>
                    <option value="'Trebuchet MS', sans-serif" className="bg-zinc-950 text-slate-100">Trebuchet (Tegas & Kontemporer)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Instansi Utama (Kop Baris 1)</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 border border-emerald-500/20 rounded-lg text-sm bg-zinc-900 text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                    placeholder="Contoh: KEMENTERIAN SEKRETARIAT KEBANGSAAN"
                    value={instansiUtama}
                    onChange={(e) => setInstansiUtama(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Organisasi / Departemen (Kop Baris 2)</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 border border-emerald-500/20 rounded-lg text-sm bg-zinc-900 text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                    placeholder="Contoh: REPUBLIK INDONESIA"
                    value={instansiSub}
                    onChange={(e) => setInstansiSub(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Alamat Lengkap</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 border border-emerald-500/20 rounded-lg text-sm bg-zinc-900 text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                    placeholder="Contoh: Jl. Diponegoro No. 20, Jakarta"
                    value={alamat}
                    onChange={(e) => setAlamat(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Kontak / Kontak Baris Bawah</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 border border-emerald-500/20 rounded-lg text-sm bg-zinc-900 text-slate-100 placeholder-slate-500 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                    placeholder="Contoh: Telp: (021) 12456"
                    value={kontak}
                    onChange={(e) => setKontak(e.target.value)}
                  />
                </div>
              </div>

              {/* Real-time Kop Preview Card */}
              <div className="bg-zinc-900/40 rounded-xl p-5 border border-emerald-500/15 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Live Preview Kop Surat</div>
                  <div className="bg-white p-5 rounded-lg border border-slate-250 shadow-xs text-center relative overflow-hidden">
                    {/* Embedded logo visualization */}
                    <div className="flex items-center justify-center gap-3 border-b-2 border-double border-slate-800 pb-3">
                      {renderLogo()}
                      <div className="text-center" style={{ fontFamily: kopFontFamily }}>
                        <div className="text-xs font-bold text-slate-900 uppercase tracking-wide">{instansiUtama || 'KOP UTAMA'}</div>
                        <div className="text-[10px] font-semibold text-slate-700 uppercase tracking-wider mt-0.5">{instansiSub}</div>
                        <div className="text-[8px] text-slate-500 mt-1 leading-normal max-w-sm mx-auto">{alamat}</div>
                        <div className="text-[7.5px] text-slate-400 font-mono mt-0.5">{kontak}</div>
                      </div>
                    </div>
                    {/* Simulated paper body lines */}
                    <div className="mt-4 space-y-2">
                      <div className="h-2 w-1/3 bg-slate-100 rounded-sm mx-auto"></div>
                      <div className="h-1.5 w-full bg-slate-50 rounded-sm"></div>
                      <div className="h-1.5 w-full bg-slate-50 rounded-sm"></div>
                    </div>
                  </div>
                </div>

                <div className="bg-emerald-500/10 p-3 rounded-lg border border-emerald-500/20 mt-4 text-[11px] leading-relaxed text-emerald-300 font-medium">
                  <strong>Standardisasi Kop:</strong> Setelah mendesain bentuk luar struktur instansi Anda, tekan langkah berikutnya di kanan bawah untuk mengonfigurasi AI penulisan isi surat formal otomatis secara rapi.
                </div>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-emerald-500/10">
              <button
                type="button"
                onClick={() => setActiveStep('konten')}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 hover:shadow-lg hover:shadow-emerald-500/10 text-white font-bold rounded-lg text-xs tracking-wide flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                Langkah Berikutnya (Pilih Isi) <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: AI DYNAMIC CONTENT GENERATOR */}
        {activeStep === 'konten' && (
          <div className="space-y-6 animate-fade-in text-slate-100">
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-start">
              {/* Query parameters panel */}
              <div className="xl:col-span-5 space-y-4">
                <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-emerald-500/10 pb-2">
                  <Sparkles className="h-4 w-4 text-emerald-400" /> AI Asisten Konfigurator
                </h3>

                {/* Metadata details quick fill */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Arah Surat</label>
                    <select
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 text-slate-200 rounded-md font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                      value={type}
                      onChange={(e) => setType(e.target.value as LetterType)}
                    >
                      <option value="keluar" className="bg-zinc-950 text-slate-100">Keluar (Dibuat Eksternal)</option>
                      <option value="masuk" className="bg-zinc-950 text-slate-100">Masuk (Diarsipkan)</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Klasifikasi Kategori</label>
                    <select
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 text-slate-200 rounded-md font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                    >
                      {LETTER_CATEGORIES.map((c) => (
                        <option key={c} value={c} className="bg-zinc-950 text-slate-101">{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Nomor Registrasi Surat</label>
                    <input
                      type="text"
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 text-slate-205 rounded-md font-mono focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                      value={number}
                      onChange={(e) => setNumber(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Urgensi Sifat</label>
                    <select
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 text-slate-200 rounded-md font-medium focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20"
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as LetterPriority)}
                    >
                      <option value="biasa" className="bg-zinc-950 text-slate-101">Biasa (Dinas Reguler)</option>
                      <option value="penting" className="bg-zinc-950 text-slate-101">Penting (Atensi Lebih)</option>
                      <option value="sangat_penting" className="bg-zinc-950 text-slate-101">Sangat Penting (Prioritas Tinggi)</option>
                      <option value="rahasia" className="bg-zinc-950 text-slate-101">Rahasia</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Perihal / Hal Pokok Surat</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 bg-zinc-900 border border-emerald-500/20 text-slate-200 rounded-lg text-sm focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 placeholder-slate-500"
                    placeholder="Contoh: Permohonan Koordinasi Peminjaman Ruangan Rapat"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-1.5">Mitra Penerima / Pengirim Terkait</label>
                  <input
                    type="text"
                    className="block w-full px-3 py-2 bg-zinc-900 border border-emerald-500/20 text-slate-200 rounded-lg text-sm focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 placeholder-slate-500"
                    placeholder="Contoh: Kepala Badan Kepegawaian Daerah"
                    value={senderOrRecipient}
                    onChange={(e) => setSenderOrRecipient(e.target.value)}
                  />
                </div>

                {/* AI prompt specific instruction */}
                <div className="p-3.5 bg-emerald-500/5 border border-emerald-500/20 rounded-lg space-y-2">
                  <label className="block text-xs font-bold text-emerald-300 uppercase flex items-center gap-1.5">
                    <Languages className="h-3.5 w-3.5 text-emerald-400" /> Instruksi Konten Dinamis
                  </label>
                  <textarea
                    rows={2}
                    className="block w-full p-2 bg-zinc-900 border border-emerald-500/20 rounded text-xs text-slate-100 focus:outline-hidden focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/20 placeholder-slate-500"
                    placeholder="Detail instruksi/agenda, contoh: 'Rapat hari Jumat jam 9 pagi membahas anggaran triwulan III'"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                  />
                  <div className="flex gap-2">
                    <button
                      type="button"
                      disabled={isGenerating}
                      onClick={handleAutoGenerateContent}
                      className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-md flex items-center justify-center gap-1 disabled:opacity-55 cursor-pointer shadow-xs"
                    >
                      {isGenerating ? 'Menghubungkan AI...' : 'Hasilkan dengan AI'}
                      <Sparkles className="h-3 w-3" />
                    </button>
                    <button
                      type="button"
                      onClick={generateLocalSmartTemplate}
                      className="py-1.5 px-3 bg-zinc-900 hover:bg-zinc-800 border border-emerald-500/20 text-emerald-300 text-xs font-bold rounded-md flex items-center justify-center gap-1 cursor-pointer"
                    >
                      Bawaan Lokal
                    </button>
                  </div>
                </div>

                {/* PILIH & UNGGAH TEMPLAT SURAT */}
                <div className="p-3.5 bg-zinc-900/60 border border-emerald-500/15 rounded-lg space-y-3">
                  <label className="block text-xs font-bold text-slate-205 uppercase flex items-center gap-1.5">
                    <LayoutTemplate className="h-4 w-4 text-emerald-400" />
                    Pilih & Unggah Templat Surat
                  </label>
                  
                  {/* Preset Template buttons */}
                  <div className="space-y-1.5">
                    <span className="block text-[10px] font-bold text-slate-500 uppercase">Pilihan Templat Cepat</span>
                    <div className="grid grid-cols-1 gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleLoadPresetTemplate('kemenag')}
                        className="py-1.5 px-2.5 bg-zinc-900 hover:bg-emerald-500/10 border border-emerald-500/15 hover:border-emerald-500/35 text-slate-300 text-left text-xs font-semibold rounded-md transition-all flex items-center justify-between group cursor-pointer"
                      >
                        <span>Surat ke Kemenag (LPJ BOP)</span>
                        <ChevronRight className="h-3 w-3 text-slate-500 group-hover:text-emerald-400 animate-pulse" />
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => handleLoadPresetTemplate('siswa')}
                        className="py-1.5 px-2.5 bg-zinc-900 hover:bg-emerald-500/10 border border-emerald-500/15 hover:border-emerald-500/35 text-slate-300 text-left text-xs font-semibold rounded-md transition-all flex items-center justify-between group cursor-pointer"
                      >
                        <span>Siswa / Kesiswaan (Rekomendasi Seleksi)</span>
                        <ChevronRight className="h-3 w-3 text-slate-500 group-hover:text-emerald-400" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleLoadPresetTemplate('legalisir')}
                        className="py-1.5 px-2.5 bg-zinc-900 hover:bg-emerald-500/10 border border-emerald-500/15 hover:border-emerald-500/35 text-slate-300 text-left text-xs font-semibold rounded-md transition-all flex items-center justify-between group cursor-pointer"
                      >
                        <span>Legalisir Ijazah (Pernyataan Absah)</span>
                        <ChevronRight className="h-3 w-3 text-slate-500 group-hover:text-emerald-400" />
                      </button>
                    </div>
                  </div>

                  {/* Upload custom letter template section */}
                  <div className="pt-2 border-t border-emerald-500/15">
                    <span className="block text-[10px] font-bold text-slate-500 uppercase mb-1.5">Unggah Berkas Templat Baru</span>
                    <div className="relative border border-dashed border-emerald-500/25 hover:border-emerald-500/50 rounded-lg p-3 bg-zinc-950 text-center hover:bg-emerald-500/5 cursor-pointer group transition-all">
                      <input
                        type="file"
                        accept=".txt,.md,.json"
                        onChange={handleUploadTemplate}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                      />
                      <div className="flex flex-col items-center justify-center gap-1">
                        <Upload className="h-5 w-5 text-slate-500 group-hover:text-emerald-400 transition-colors" />
                        <span className="text-xs font-semibold text-slate-300 group-hover:text-slate-100">Pilih atau Seret Berkas</span>
                        <span className="text-[9px] text-slate-500 font-medium font-mono">Format .txt, .md, atau .json</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dynamic Text Editor Sheet */}
              <div className="xl:col-span-7 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Lembar Catatan / Editor Redaksional Surat
                  </label>
                  <span className="text-[10px] text-emerald-400 font-mono italic">Bisa Diedit</span>
                </div>

                {errorMessage && (
                  <div className="p-2.5 bg-amber-500/10 border border-amber-500/25 rounded-lg text-[11px] text-amber-305 font-semibold">
                    {errorMessage}
                  </div>
                )}

                <textarea
                  rows={15}
                  className="block w-full p-4 border border-emerald-500/20 rounded-xl text-xs font-sans font-medium bg-zinc-900/80 text-slate-100 leading-relaxed focus:bg-zinc-900 focus:outline-hidden focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500"
                  placeholder="Isi redaksi surat Anda akan tergenerate di sini. Anda juga bisa langsung mengetik, mengubah, atau menyalin isi surat pendukung secara manual sesuai kebutuhan."
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-emerald-500/10">
              <button
                type="button"
                onClick={() => setActiveStep('kop')}
                className="px-4 py-2 border border-emerald-500/20 rounded-lg text-xs font-bold text-slate-300 hover:bg-zinc-900 hover:text-white transition-colors"
              >
                Kembali ke Kop
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!summary.trim()) {
                    alert('Harap isi atau generate redaksi surat terlebih dahulu sebelum lanjut ke pengesahan tanda tangan!');
                    return;
                  }
                  setActiveStep('ttd');
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 hover:shadow-lg hover:shadow-emerald-500/10 text-white font-bold rounded-lg text-xs tracking-wide flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                Lanjut Langkah 3 (Tanda Tangan) <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: DIGITAL SIGNATURE GENERATION */}
        {activeStep === 'ttd' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Signature Board config panel */}
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-100 uppercase tracking-wider flex items-center gap-1.5 border-b border-emerald-500/10 pb-2">
                  <PenTool className="h-4 w-4 text-emerald-400" /> Otentikasi & Tanda Tangan
                </h3>

                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSignatureMode('draw');
                    }}
                    className={`py-2 px-1 text-[11px] font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      signatureMode === 'draw'
                        ? 'bg-emerald-500/20 border-emerald-450 text-emerald-305 shadow-sm font-bold'
                        : 'bg-zinc-900 border-emerald-500/10 text-slate-400 hover:bg-zinc-850'
                    }`}
                  >
                    Gores Manual
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSignatureMode('upload');
                    }}
                    className={`py-2 px-1 text-[11px] font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      signatureMode === 'upload'
                        ? 'bg-emerald-500/20 border-emerald-450 text-emerald-305 shadow-sm font-bold'
                        : 'bg-zinc-900 border-emerald-500/10 text-slate-400 hover:bg-zinc-850'
                    }`}
                  >
                    Unggah Berkas
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSignatureMode('qr');
                    }}
                    className={`py-2 px-1 text-[11px] font-semibold rounded-lg border text-center transition-all cursor-pointer ${
                      signatureMode === 'qr'
                        ? 'bg-emerald-500/20 border-emerald-450 text-emerald-305 shadow-sm font-bold'
                        : 'bg-zinc-900 border-emerald-500/10 text-slate-400 hover:bg-zinc-850'
                    }`}
                  >
                    QR Elektronik
                  </button>
                </div>

                {/* Signer Bio Config */}
                <div className="space-y-3 bg-zinc-900/60 p-4 border border-emerald-500/20 rounded-xl">
                  <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Identifikasi Penandatangan</div>
                  
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Nama Pejabat Penandatangan</label>
                    <input
                      type="text"
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 rounded-md text-slate-100 focus:outline-hidden focus:border-emerald-500"
                      value={signerName}
                      onChange={(e) => setSignerName(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Jabatan Struktural</label>
                    <input
                      type="text"
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 rounded-md text-slate-100 focus:outline-hidden focus:border-emerald-500"
                      value={signerRole}
                      onChange={(e) => setSignerRole(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">NIP (Nomor Induk Pegawai)</label>
                    <input
                      type="text"
                      className="block w-full px-2 py-1.5 text-xs bg-zinc-900 border border-emerald-500/20 rounded-md font-mono text-slate-100 focus:outline-hidden focus:border-emerald-500"
                      value={signerId}
                      onChange={(e) => setSignerId(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic canvas sign pad */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">
                    {signatureMode === 'draw'
                      ? 'Goresan Tanda Tangan Digital'
                      : signatureMode === 'upload'
                      ? 'Unggah File Tanda Tangan'
                      : 'QR Kode Validasi QR E-Sign'}
                  </label>
                  {signatureMode === 'draw' && (
                    <button
                      type="button"
                      onClick={clearCanvas}
                      className="text-[11px] text-red-400 font-bold hover:underline cursor-pointer"
                    >
                      Ulangi / Bersihkan Pad
                    </button>
                  )}
                </div>

                {signatureMode === 'draw' ? (
                  <div className="flex flex-col gap-3">
                    {/* Drawing controls */}
                    <div className="flex items-center gap-3 text-xs bg-zinc-900 border border-emerald-500/10 p-2 rounded-lg">
                      <span className="font-semibold text-slate-400 text-[10px]">Pena:</span>
                      <div className="flex items-center gap-1.5">
                        {['#1e3a8a', '#0369a1', '#0f172a'].map((col) => (
                          <button
                            key={col}
                            onClick={() => setInkColor(col)}
                            type="button"
                            className={`h-4.5 w-4.5 rounded-full border border-slate-300 transition-all cursor-pointer ${
                              inkColor === col ? 'ring-2 ring-emerald-500 scale-110' : ''
                            }`}
                            style={{ backgroundColor: col }}
                          />
                        ))}
                      </div>
                      <span className="font-semibold text-slate-400 text-[10px] ml-auto">Tebal:</span>
                      <input
                        type="range"
                        min="1"
                        max="8"
                        className="w-16 h-1 bg-zinc-800 rounded-lg cursor-pointer accent-emerald-500"
                        value={penWidth}
                        onChange={(e) => setPenWidth(Number(e.target.value))}
                      />
                    </div>

                    <div className="border border-emerald-500/20 bg-zinc-950 rounded-xl shadow-xs overflow-hidden flex flex-col">
                      <canvas
                        ref={canvasRef}
                        width={400}
                        height={180}
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                        onTouchStart={startDrawing}
                        onTouchMove={draw}
                        onTouchEnd={stopDrawing}
                        className="w-full bg-zinc-900/60 cursor-crosshair touch-none"
                        style={{ height: '180px' }}
                      />
                      <div className="p-2.5 bg-zinc-900 border-t border-emerald-500/10 text-center text-[10px] font-sans font-semibold text-slate-400">
                        Seret kursor/sentuh di atas untuk membubuhkan goresan tanda tangan unik Anda
                      </div>
                    </div>
                  </div>
                ) : signatureMode === 'upload' ? (
                  <div className="p-4 bg-zinc-900/40 border border-emerald-500/15 rounded-xl animate-fade-in space-y-3 flex flex-col justify-center min-h-[220px]">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 font-bold uppercase">Unggah File Gambar Tanda Tangan</span>
                      {uploadedSignatureUrl && (
                        <button
                          type="button"
                          onClick={() => setUploadedSignatureUrl(undefined)}
                          className="text-[10px] text-red-400 hover:text-red-300 font-bold underline cursor-pointer"
                        >
                          Hapus File
                        </button>
                      )}
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="block w-full text-xs text-slate-350 file:mr-4 file:py-1.5 file:px-3 file:rounded-md file:border file:border-emerald-500/20 file:text-xs file:font-bold file:bg-emerald-500/15 file:text-emerald-300 hover:file:bg-emerald-500/25 cursor-pointer font-sans"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                           const reader = new FileReader();
                           reader.onloadend = () => {
                             setUploadedSignatureUrl(reader.result as string);
                           };
                           reader.readAsDataURL(file);
                        }
                      }}
                    />
                    {uploadedSignatureUrl ? (
                      <div className="mt-2 text-center p-3 bg-zinc-950 rounded-lg border border-emerald-500/20">
                        <img 
                          src={uploadedSignatureUrl} 
                          alt="Uploaded Signature" 
                          className="max-h-24 mx-auto object-contain"
                          referrerPolicy="no-referrer"
                        />
                        <span className="text-[9px] text-slate-400 block mt-1">Preview Tanda Tangan Terunggah</span>
                      </div>
                    ) : (
                      <div className="text-center py-4 text-[11px] text-slate-400 border border-dashed border-emerald-500/20 rounded-lg">
                        Mendukung format PNG / JPG tanda tangan digital (transparan atau putih)
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="border border-emerald-500/15 bg-zinc-950 rounded-xl p-6 flex flex-col items-center justify-center text-center space-y-3 min-h-[220px]">
                    <div className="relative p-3 bg-zinc-900 border-2 border-dashed border-emerald-500/25 rounded-xl">
                      <QrCode className="h-20 w-20 text-emerald-300" />
                      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-zinc-950 px-1.5 py-0.5 rounded-sm border border-emerald-500/30 text-[6px] font-extrabold tracking-widest text-emerald-300">
                        E-SIGN
                      </div>
                    </div>
                    <div className="max-w-xs">
                      <p className="text-xs font-bold text-slate-300">QR Validasi Sertifikat Digital BSrE</p>
                      <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                        Menerapkan QR-Code verifikasi sertifikasi instansi negara untuk menjamin keaslian dokumen kearsipan secara legal formal.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-emerald-500/10">
              <button
                type="button"
                onClick={() => setActiveStep('konten')}
                className="px-4 py-2 border border-emerald-500/20 rounded-lg text-xs font-bold text-slate-300 hover:bg-zinc-900 hover:text-white transition-colors"
              >
                Kembali ke Isi Surat
              </button>
              <button
                type="button"
                onClick={handlePublishLetterToArchive}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 border border-emerald-700 text-white font-extrabold rounded-lg text-xs tracking-wider flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Check className="h-4.5 w-4.5" /> PENERBITAN & FORMAT SELESAI
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
